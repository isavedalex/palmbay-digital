/**
 * Schema.org JSON-LD builders for the objects a local-business site needs.
 *
 * Each builder returns a plain node. Compose the nodes for a page with
 * `graph([...])` and render once with `<JsonLd data={graph} />`. Nodes carry
 * stable `@id`s (see `ids`) so the business declared on the home page can be
 * referenced from a Service, Article or WebSite node elsewhere — Google merges
 * nodes by `@id`.
 *
 * House rules (the `palmbay-structured-data` playbook is the authority):
 * - Server-render the script. Never `next/script`, never after hydration.
 * - Every URL comes from `lib/seo/site-url.ts` (`absoluteUrl()`), never a literal.
 * - Use the most specific LocalBusiness subtype, as an array when several apply
 *   (`['Electrician', 'Plumber']`). Never `ProfessionalService` (deprecated by
 *   schema.org) and never `Photographer` (not a type).
 * - Mark up only what is visible on the page.
 * - No self-authored `aggregateRating` / `review` on the business's own site:
 *   Google's self-serving rule makes such pages ineligible for stars anyway.
 * - FAQPage, SearchAction and HowTo no longer produce Google rich results.
 */

export type JsonLdNode = Record<string, unknown>
type JsonLd = JsonLdNode

export const SCHEMA_CONTEXT = 'https://schema.org'

const clean = <T extends JsonLd>(obj: T): T => {
  for (const k of Object.keys(obj)) {
    const v = obj[k]
    if (v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0)) delete obj[k]
  }
  return obj
}

const trimSlash = (url: string) => url.replace(/\/+$/, '')

/** A reference to another node in the graph: `{'@id': '…'}`. */
export interface IdRef {
  '@id': string
}
export const ref = (id: string): IdRef => ({'@id': id})
const isRef = (v: unknown): v is IdRef =>
  typeof v === 'object' && v !== null && '@id' in v && Object.keys(v).length === 1

/**
 * The house `@id` conventions. `siteUrl` is `SITE_URL`; `pageUrl` is the
 * absolute canonical URL of the page the node describes.
 */
export const ids = {
  business: (siteUrl: string) => `${trimSlash(siteUrl)}/#business`,
  organization: (siteUrl: string) => `${trimSlash(siteUrl)}/#organization`,
  website: (siteUrl: string) => `${trimSlash(siteUrl)}/#website`,
  webpage: (pageUrl: string) => `${trimSlash(pageUrl)}#webpage`,
  breadcrumb: (pageUrl: string) => `${trimSlash(pageUrl)}#breadcrumb`,
  article: (pageUrl: string) => `${trimSlash(pageUrl)}#article`,
  service: (siteUrl: string, slug: string) => `${trimSlash(siteUrl)}/#service-${slug}`,
  person: (siteUrl: string, slug: string) => `${trimSlash(siteUrl)}/#person-${slug}`,
  menu: (pageUrl: string) => `${trimSlash(pageUrl)}#menu`,
  location: (pageUrl: string) => `${trimSlash(pageUrl)}#business`,
}

/**
 * Wrap nodes in one `@context` + `@graph` document. Per-node `@context` keys
 * are stripped so builders can be used standalone or inside a graph.
 */
export function graph(nodes: Array<JsonLd | null | undefined | false>): JsonLd {
  const list = nodes
    .filter((n): n is JsonLd => !!n)
    .map((n) => {
      const {['@context']: _ctx, ...rest} = n
      return rest
    })
  return {'@context': SCHEMA_CONTEXT, '@graph': list}
}

export interface PostalAddress {
  streetAddress?: string
  addressLocality?: string
  addressRegion?: string
  postalCode?: string
  /** ISO 3166-1 alpha-2 — 'GB' for the UK. */
  addressCountry?: string
}

export interface OpeningHours {
  /** e.g. ['Monday','Tuesday'] — English day names, as Google requires. */
  dayOfWeek: string[]
  /** 'HH:MM' 24h. Omit both and set `closed: true` for a closed day. */
  opens?: string
  closes?: string
  /** Closed all day → emitted as opens/closes '00:00' (Google's convention). */
  closed?: boolean
  /** ISO dates for seasonal or holiday hours. */
  validFrom?: string
  validThrough?: string
}

export function openingHoursJsonLd(hours: OpeningHours[]): JsonLd[] {
  return hours.map((h) =>
    clean({
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: h.dayOfWeek,
      opens: h.closed ? '00:00' : h.opens,
      closes: h.closed ? '00:00' : h.closes,
      validFrom: h.validFrom,
      validThrough: h.validThrough,
    }),
  )
}

/** A served place: a bare name becomes `{'@type': 'City'}`. */
export type AreaServed =
  | string
  | {type?: 'City' | 'AdministrativeArea' | 'Country' | 'Place'; name: string}

const areaServedJsonLd = (areas?: AreaServed[]) =>
  areas?.map((a) =>
    typeof a === 'string' ? {'@type': 'City', name: a} : {'@type': a.type ?? 'City', name: a.name},
  )

export interface LocalBusinessInput {
  /**
   * Most specific schema.org LocalBusiness subtype(s), e.g. 'Plumber',
   * 'Restaurant', 'GeneralContractor', ['Electrician','Plumber']. Default
   * 'LocalBusiness'. Do not use 'ProfessionalService' (deprecated) or
   * 'Photographer' (not a type).
   */
  type?: string | string[]
  /** Override the `@id`; default `ids.business(url)`. */
  id?: string
  name: string
  legalName?: string
  /** The site origin for a single-location business, or the location page URL. */
  url: string
  /** Absolute URL of a representative photo (or several). */
  image?: string | string[]
  /** Absolute URL of the logo, ≥112×112, legible on white. */
  logo?: string
  description?: string
  /** '+44…' international form. */
  telephone?: string
  email?: string
  vatID?: string
  /** '£' to '££££', under 100 characters. */
  priceRange?: string
  address?: PostalAddress
  /** WGS 84, at least 5 decimal places. */
  geo?: {latitude: number; longitude: number}
  /** Google Maps URL for the listing. */
  hasMap?: string
  areaServed?: AreaServed[]
  openingHours?: OpeningHours[]
  /** Google Business Profile, Facebook, Instagram, Checkatrade, Deliveroo… */
  sameAs?: string[]
  /** BCP 47, e.g. 'en-GB'. */
  inLanguage?: string
  /** Multi-location sites: the Organization node this location belongs to. */
  parentOrganization?: IdRef
  founder?: {name: string; url?: string; jobTitle?: string} | IdRef
  /** Services offered, as `@id` refs to Service nodes or inline Offers. */
  hasOfferCatalog?: {
    name?: string
    items: Array<{itemOffered: IdRef; price?: string; priceCurrency?: string}>
  }
  /**
   * @deprecated Google ignores self-authored ratings on LocalBusiness/Organization
   * pages (the self-serving rule) and treats embedded review widgets the same.
   * Kept for sites that aggregate reviews about *other* businesses.
   */
  aggregateRating?: {ratingValue: number; reviewCount: number}
  /** Restaurant-only extras. */
  servesCuisine?: string[]
  acceptsReservations?: boolean
  /** `@id` of a Menu node (see `menuJsonLd`). */
  hasMenu?: IdRef
}

export function localBusinessJsonLd(input: LocalBusinessInput): JsonLd {
  const founder = input.founder
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': input.type ?? 'LocalBusiness',
    '@id': input.id ?? ids.business(input.url),
    name: input.name,
    legalName: input.legalName,
    url: input.url,
    image: input.image,
    logo: input.logo,
    description: input.description,
    telephone: input.telephone,
    email: input.email,
    vatID: input.vatID,
    priceRange: input.priceRange,
    address: input.address ? clean({'@type': 'PostalAddress', ...input.address}) : undefined,
    geo: input.geo ? {'@type': 'GeoCoordinates', ...input.geo} : undefined,
    hasMap: input.hasMap,
    areaServed: areaServedJsonLd(input.areaServed),
    openingHoursSpecification: input.openingHours ? openingHoursJsonLd(input.openingHours) : undefined,
    sameAs: input.sameAs,
    inLanguage: input.inLanguage,
    parentOrganization: input.parentOrganization,
    founder: founder ? (isRef(founder) ? founder : clean({'@type': 'Person', ...founder})) : undefined,
    hasOfferCatalog: input.hasOfferCatalog
      ? clean({
          '@type': 'OfferCatalog',
          name: input.hasOfferCatalog.name,
          itemListElement: input.hasOfferCatalog.items.map((o) =>
            clean({
              '@type': 'Offer',
              itemOffered: o.itemOffered,
              price: o.price,
              priceCurrency: o.priceCurrency,
            }),
          ),
        })
      : undefined,
    aggregateRating: input.aggregateRating
      ? {
          '@type': 'AggregateRating',
          ratingValue: input.aggregateRating.ratingValue,
          reviewCount: input.aggregateRating.reviewCount,
          bestRating: 5,
          worstRating: 1,
        }
      : undefined,
    servesCuisine: input.servesCuisine,
    acceptsReservations: input.acceptsReservations,
    hasMenu: input.hasMenu,
  })
}

export function organizationJsonLd(input: {
  id?: string
  name: string
  legalName?: string
  url: string
  logo?: string
  description?: string
  email?: string
  telephone?: string
  vatID?: string
  address?: PostalAddress
  sameAs?: string[]
  contactPoint?: {
    telephone: string
    contactType?: string
    email?: string
    areaServed?: string
    availableLanguage?: string[]
  }
  /** Multi-location: refs to each LocalBusiness node. */
  subOrganization?: IdRef[]
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'Organization',
    '@id': input.id ?? ids.organization(input.url),
    name: input.name,
    legalName: input.legalName,
    url: input.url,
    logo: input.logo,
    description: input.description,
    email: input.email,
    telephone: input.telephone,
    vatID: input.vatID,
    address: input.address ? clean({'@type': 'PostalAddress', ...input.address}) : undefined,
    sameAs: input.sameAs,
    contactPoint: input.contactPoint
      ? clean({'@type': 'ContactPoint', contactType: 'customer service', ...input.contactPoint})
      : undefined,
    subOrganization: input.subOrganization,
  })
}

export function webSiteJsonLd(input: {
  id?: string
  name: string
  alternateName?: string | string[]
  url: string
  /** `@id` of the business / organization node. */
  publisher?: IdRef
  inLanguage?: string
  /**
   * @deprecated The sitelinks search box was retired by Google in Nov 2024.
   * Harmless, but emit it only for sites with real on-site search.
   */
  searchUrlTemplate?: string
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'WebSite',
    '@id': input.id ?? ids.website(input.url),
    name: input.name,
    alternateName: input.alternateName,
    url: input.url,
    publisher: input.publisher,
    inLanguage: input.inLanguage,
    potentialAction: input.searchUrlTemplate
      ? {
          '@type': 'SearchAction',
          target: {'@type': 'EntryPoint', urlTemplate: input.searchUrlTemplate},
          'query-input': 'required name=search_term_string',
        }
      : undefined,
  })
}

export function webPageJsonLd(input: {
  /** 'WebPage' | 'AboutPage' | 'ContactPage' | 'CollectionPage' | 'ImageGallery'… */
  type?: string
  id?: string
  url: string
  name: string
  description?: string
  /** `ids.website(siteUrl)` */
  isPartOf?: IdRef
  /** What the page is about — usually the business node. */
  about?: IdRef
  /** `ids.breadcrumb(url)` when a BreadcrumbList node is on the page. */
  breadcrumb?: IdRef
  primaryImageOfPage?: string
  inLanguage?: string
  datePublished?: string
  dateModified?: string
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': input.type ?? 'WebPage',
    '@id': input.id ?? ids.webpage(input.url),
    url: input.url,
    name: input.name,
    description: input.description,
    isPartOf: input.isPartOf,
    about: input.about,
    breadcrumb: input.breadcrumb,
    primaryImageOfPage: input.primaryImageOfPage
      ? {'@type': 'ImageObject', url: input.primaryImageOfPage}
      : undefined,
    inLanguage: input.inLanguage,
    datePublished: input.datePublished,
    dateModified: input.dateModified,
  })
}

export function articleJsonLd(input: {
  /** 'Article' | 'BlogPosting' | 'NewsArticle' */
  type?: string
  id?: string
  headline: string
  description?: string
  url: string
  /** 16:9, 4:3 and 1:1 crops when available. */
  image?: string | string[]
  /** ISO 8601 with timezone. */
  datePublished: string
  dateModified?: string
  author: {name: string; url?: string; sameAs?: string[]} | IdRef
  /** Inline, or a ref to the business/organization node (preferred). */
  publisher: {name: string; logo?: string} | IdRef
  inLanguage?: string
  /** Defaults to a WebPage ref for `url`. */
  mainEntityOfPage?: IdRef
  keywords?: string[]
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': input.type ?? 'BlogPosting',
    '@id': input.id ?? ids.article(input.url),
    mainEntityOfPage: input.mainEntityOfPage ?? {'@type': 'WebPage', '@id': input.url},
    headline: input.headline,
    description: input.description,
    url: input.url,
    image: input.image,
    datePublished: input.datePublished,
    dateModified: input.dateModified ?? input.datePublished,
    author: isRef(input.author) ? input.author : clean({'@type': 'Person', ...input.author}),
    publisher: isRef(input.publisher)
      ? input.publisher
      : clean({
          '@type': 'Organization',
          name: input.publisher.name,
          logo: input.publisher.logo ? {'@type': 'ImageObject', url: input.publisher.logo} : undefined,
        }),
    inLanguage: input.inLanguage,
    keywords: input.keywords,
  })
}

export function serviceJsonLd(input: {
  id?: string
  name: string
  description?: string
  url?: string
  serviceType?: string
  areaServed?: AreaServed[]
  /** Inline, or (preferred) a ref to the business node that is on the same page. */
  provider: {name: string; url: string} | IdRef
  offers?: {price?: string; priceCurrency?: string; description?: string}
  inLanguage?: string
  image?: string
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'Service',
    '@id': input.id,
    name: input.name,
    description: input.description,
    url: input.url,
    image: input.image,
    serviceType: input.serviceType,
    areaServed: areaServedJsonLd(input.areaServed),
    provider: isRef(input.provider)
      ? input.provider
      : {'@type': 'LocalBusiness', name: input.provider.name, url: input.provider.url},
    offers: input.offers ? clean({'@type': 'Offer', ...input.offers}) : undefined,
    inLanguage: input.inLanguage,
  })
}

export function personJsonLd(input: {
  id?: string
  name: string
  url?: string
  image?: string
  jobTitle?: string
  description?: string
  worksFor?: {name: string; url?: string} | IdRef
  sameAs?: string[]
  knowsAbout?: string[]
  memberOf?: Array<{name: string; url?: string}>
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'Person',
    '@id': input.id,
    name: input.name,
    url: input.url,
    image: input.image,
    jobTitle: input.jobTitle,
    description: input.description,
    worksFor: input.worksFor
      ? isRef(input.worksFor)
        ? input.worksFor
        : clean({'@type': 'Organization', ...input.worksFor})
      : undefined,
    sameAs: input.sameAs,
    knowsAbout: input.knowsAbout,
    memberOf: input.memberOf?.map((m) => clean({'@type': 'Organization', ...m})),
  })
}

/**
 * Valid schema.org, but Google retired FAQ rich results on 7 May 2026. Emit it
 * only where the questions are visible on the page; it helps AI crawlers, not
 * SERP stars.
 */
export function faqPageJsonLd(
  items: Array<{question: string; answer: string}>,
  opts: {id?: string} = {},
): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'FAQPage',
    '@id': opts.id,
    mainEntity: items.map((i) => ({
      '@type': 'Question',
      name: i.question,
      acceptedAnswer: {'@type': 'Answer', text: i.answer},
    })),
  })
}

/**
 * Breadcrumb trail. Show the user's path, not the URL structure. The last
 * item may omit `url` (Google allows it). Use the localised path on i18n sites.
 */
export function breadcrumbJsonLd(
  items: Array<{name: string; url?: string}>,
  opts: {id?: string} = {},
): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'BreadcrumbList',
    '@id': opts.id,
    itemListElement: items.map((item, i) =>
      clean({
        '@type': 'ListItem',
        position: i + 1,
        name: item.name,
        item: item.url,
      }),
    ),
  })
}

/** Directory / listing pages: an ordered list of things, by ref or by name+url. */
export function itemListJsonLd(input: {
  id?: string
  name?: string
  items: Array<IdRef | {name: string; url: string}>
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'ItemList',
    '@id': input.id,
    name: input.name,
    numberOfItems: input.items.length,
    itemListElement: input.items.map((it, i) =>
      isRef(it)
        ? {'@type': 'ListItem', position: i + 1, item: it}
        : {'@type': 'ListItem', position: i + 1, name: it.name, url: it.url},
    ),
  })
}

export interface MenuItemInput {
  name: string
  description?: string
  /** One price, or several (with `priceLabels` on the section, e.g. ['10"', '14"']). */
  price: number | number[]
  vegan?: boolean
  vegetarian?: boolean
}
export interface MenuSectionInput {
  name: string
  description?: string
  priceLabels?: string[]
  items: MenuItemInput[]
}

/** A restaurant menu (lifted from palms-pizzeria). Reference it from `hasMenu`. */
export function menuJsonLd(input: {
  id?: string
  name: string
  url: string
  /** ISO 4217, e.g. 'GBP'. */
  currency: string
  inLanguage?: string
  sections: MenuSectionInput[]
}): JsonLd {
  return clean({
    '@context': SCHEMA_CONTEXT,
    '@type': 'Menu',
    '@id': input.id ?? ids.menu(input.url),
    name: input.name,
    url: input.url,
    inLanguage: input.inLanguage,
    hasMenuSection: input.sections.map((section) =>
      clean({
        '@type': 'MenuSection',
        name: section.name,
        description: section.description,
        hasMenuItem: section.items.map((item) => {
          const prices = Array.isArray(item.price) ? item.price : [item.price]
          const labels = Array.isArray(item.price) && section.priceLabels ? section.priceLabels : []
          return clean({
            '@type': 'MenuItem',
            name: item.name,
            description: item.description,
            suitableForDiet: item.vegan
              ? 'https://schema.org/VeganDiet'
              : item.vegetarian
                ? 'https://schema.org/VegetarianDiet'
                : undefined,
            offers: prices.map((price, i) =>
              clean({
                '@type': 'Offer',
                price: price.toFixed(2),
                priceCurrency: input.currency,
                name: labels[i] ? `${item.name} (${labels[i]})` : undefined,
              }),
            ),
          })
        }),
      }),
    ),
  })
}
