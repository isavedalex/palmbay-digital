const SKIP_KEYS = new Set(['_id', '_type', '_rev', '_createdAt', '_updatedAt', '_key', 'seo', 'slug'])

/**
 * Walk a Sanity document and collect its human-readable strings — Portable
 * Text spans, plain string fields — into one blob for the AI drafts. Keys
 * that are obviously not copy (ids, slugs, the seo object itself) are skipped.
 */
export function extractDocText(value: unknown, limit = 6000): string {
  const out: string[] = []
  let total = 0
  const push = (s: string) => {
    const t = s.trim()
    if (!t || total >= limit) return
    out.push(t)
    total += t.length + 1
  }
  const walk = (v: unknown, key?: string): void => {
    if (total >= limit || v == null) return
    if (typeof v === 'string') {
      if (key && SKIP_KEYS.has(key)) return
      // Skip refs, urls and image ids — none of them are copy.
      if (/^(image-|file-|https?:\/\/)/.test(v) || key === '_ref') return
      push(v)
      return
    }
    if (Array.isArray(v)) {
      v.forEach((item) => walk(item))
      return
    }
    if (typeof v === 'object') {
      const obj = v as Record<string, unknown>
      if (obj._type === 'span' && typeof obj.text === 'string') {
        push(obj.text)
        return
      }
      for (const [k, val] of Object.entries(obj)) {
        if (SKIP_KEYS.has(k) && k !== 'seo') continue
        if (k === 'seo') continue
        walk(val, k)
      }
    }
  }
  walk(value)
  return out.join('\n').slice(0, limit)
}
