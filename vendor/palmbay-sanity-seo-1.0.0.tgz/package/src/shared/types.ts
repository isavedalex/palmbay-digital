/**
 * The stored shape of an `seoFields` object, exactly as the schema in
 * `src/seo-fields/schema` writes it. Field names are kept identical to
 * sanity-plugin-seofields v1.x so existing documents load unchanged.
 *
 * This file must stay free of `sanity` imports: `./next` and `./server`
 * import it and neither should drag the Studio into a server bundle.
 */

export interface SanityImageRef {
  _type?: 'image'
  asset?: {_ref?: string; _type?: 'reference'; url?: string}
  alt?: string
  hotspot?: unknown
  crop?: unknown
}

export interface SeoRobots {
  noIndex?: boolean
  noFollow?: boolean
  noTranslate?: boolean
  noImageIndex?: boolean
}

export interface SeoOpenGraph {
  url?: string
  title?: string
  description?: string
  siteName?: string
  type?: string
  imageType?: 'upload' | 'url'
  image?: SanityImageRef
  imageUrl?: string
}

export interface SeoTwitter {
  card?: 'summary' | 'summary_large_image' | 'app' | 'player'
  site?: string
  creator?: string
  title?: string
  description?: string
  imageType?: 'upload' | 'url'
  image?: SanityImageRef
  imageUrl?: string
}

export interface SeoMetaAttribute {
  key?: string
  type?: 'string' | 'image'
  value?: string
  image?: SanityImageRef
}

export interface SeoHreflang {
  locale?: string
  url?: string
}

export interface SeoFieldsValue {
  _type?: 'seoFields'
  title?: string
  description?: string
  metaImage?: SanityImageRef
  keywords?: string[]
  focusKeyword?: string
  canonicalUrl?: string
  metaAttributes?: SeoMetaAttribute[]
  hreflangs?: SeoHreflang[]
  robots?: SeoRobots
  openGraph?: SeoOpenGraph
  twitter?: SeoTwitter
}

/** Request body the Studio posts to the `./server` handler. */
export type SeoAiRequest =
  | {task: 'alt'; imageUrl: string; context?: string}
  | {task: 'title' | 'description'; text: string; focusKeyword?: string; siteName?: string}

export interface SeoAiResponse {
  result: string
}

/** Recommended length bands — shared by the inputs, the score, and the AI prompts. */
export const SEO_LIMITS = {
  title: {min: 30, max: 60},
  description: {min: 70, max: 160},
  alt: {max: 125},
} as const
