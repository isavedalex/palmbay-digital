import {definePlugin} from 'sanity'

import {AltTextBulkTool} from './AltTextBulkTool'
import {AltTextIcon} from './AltTextIcon'

export interface AltTextOptions {
  /** Where the generator posts. Default `/api/seo-ai`. */
  endpoint?: string
  /** Document types to scan in the bulk tool. Default: every non-system document type. */
  documentTypes?: string[]
  /** Register the bulk "Alt Text" tool in the navbar. Default true. */
  bulkTool?: boolean
  apiVersion?: string
}

export {AltTextInput, type AltTextInputOptions} from './AltTextInput'
export {altTextField, altTextFields} from './altTextField'

/**
 * Adds the bulk "Alt Text" tool. Per-field generation comes from
 * `altTextField()` in your image schemas, which needs no plugin at all.
 */
export const altText = definePlugin<AltTextOptions | void>((options) => {
  const opts: AltTextOptions = options ?? {}
  return {
    name: '@palmbay/sanity-seo/alt-text',
    tools:
      opts.bulkTool === false
        ? []
        : [
            {
              name: 'alt-text',
              title: 'Alt Text',
              icon: AltTextIcon,
              component: function AltTextToolPane() {
                return <AltTextBulkTool options={opts} />
              },
            },
          ],
  }
})
