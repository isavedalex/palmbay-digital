import {Button, Flex, Text} from '@sanity/ui'
import {useCallback, useState} from 'react'
import {PatchEvent, set, useClient, useFormValue, type StringInputProps} from 'sanity'

import {requestSeoAi} from '../seo-fields/inputs/AiDraftButton'
import {DEFAULT_API_VERSION} from '../seo-fields/options'
import {extractDocText} from '../shared/extractText'

export interface AltTextInputOptions {
  aiEndpoint?: string
  apiVersion?: string
}

/**
 * Input for a string `alt` field that lives inside an image. Reads the
 * sibling `asset` ref, resolves its CDN URL and asks the server route to
 * describe it.
 */
export function AltTextInput(props: StringInputProps) {
  const {renderDefault, path, onChange, schemaType} = props
  const options = schemaType.options as AltTextInputOptions | undefined
  const endpoint = options?.aiEndpoint ?? '/api/seo-ai'
  const client = useClient({apiVersion: options?.apiVersion ?? DEFAULT_API_VERSION})
  const image = useFormValue(path.slice(0, -1)) as {asset?: {_ref?: string}} | undefined
  const rootDoc = useFormValue([]) as Record<string, unknown> | undefined
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const generate = useCallback(async () => {
    const ref = image?.asset?._ref
    if (!ref) {
      setError('Upload an image first.')
      return
    }
    setBusy(true)
    setError(null)
    try {
      const url = await client.fetch<string | null>(`*[_id == $id][0].url`, {id: ref})
      if (!url) throw new Error('Could not resolve the image URL.')
      const context = rootDoc ? extractDocText(rootDoc, 600) : undefined
      const alt = await requestSeoAi(endpoint, {task: 'alt', imageUrl: url, context})
      onChange(PatchEvent.from(set(alt)))
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }, [image?.asset?._ref, client, endpoint, rootDoc, onChange])

  return (
    <Flex direction="column" gap={2}>
      {renderDefault(props)}
      <Flex align="center" gap={3}>
        <Button
          mode="ghost"
          tone="primary"
          fontSize={1}
          padding={2}
          text={busy ? 'Describing…' : 'Generate alt text'}
          disabled={busy || !image?.asset?._ref}
          onClick={generate}
        />
        {error && (
          <Text size={1} muted>
            {error}
          </Text>
        )}
      </Flex>
    </Flex>
  )
}
