export function AltTextIcon() {
  return (
    <svg
      width="1em"
      height="1em"
      viewBox="0 0 25 25"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <rect x="4" y="5" width="17" height="15" rx="2" />
      <path d="M4 16 L9 11 L13 15 L16 12 L21 17" />
      <circle cx="16" cy="9" r="1.5" />
    </svg>
  )
}
