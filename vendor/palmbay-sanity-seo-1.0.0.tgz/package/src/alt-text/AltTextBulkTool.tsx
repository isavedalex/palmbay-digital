import {Badge, Box, Button, Card, Container, Flex, Heading, Spinner, Text} from '@sanity/ui'
import {useCallback, useEffect, useMemo, useRef, useState} from 'react'
import {useClient, useSchema} from 'sanity'
import {IntentLink} from 'sanity/router'

import {requestSeoAi} from '../seo-fields/inputs/AiDraftButton'
import {DEFAULT_API_VERSION} from '../seo-fields/options'
import type {AltTextOptions} from './index'

interface ImageHit {
  docId: string
  docType: string
  docTitle: string
  /** JSON path of the image object within the document, e.g. `hero.image` or `gallery[_key=="abc"]` */
  path: string
  assetRef: string
  url: string
  alt: string | null
}

type Status = 'idle' | 'running' | 'done'

/**
 * Walk a published document and yield every image object (`_type: 'image'`
 * with an asset) alongside the Sanity patch path to reach it. Portable Text
 * image blocks are included.
 */
function collectImages(doc: Record<string, unknown>): Array<{path: string; assetRef: string; alt: string | null}> {
  const out: Array<{path: string; assetRef: string; alt: string | null}> = []
  const walk = (v: unknown, path: string) => {
    if (!v || typeof v !== 'object') return
    if (Array.isArray(v)) {
      v.forEach((item, i) => {
        const key = item && typeof item === 'object' ? (item as {_key?: string})._key : undefined
        walk(item, key ? `${path}[_key=="${key}"]` : `${path}[${i}]`)
      })
      return
    }
    const obj = v as Record<string, unknown>
    const asset = obj.asset as {_ref?: string} | undefined
    if (obj._type === 'image' && asset?._ref?.startsWith('image-')) {
      out.push({path, assetRef: asset._ref, alt: typeof obj.alt === 'string' ? obj.alt : null})
      return
    }
    for (const [k, val] of Object.entries(obj)) {
      if (k.startsWith('_')) continue
      walk(val, path ? `${path}.${k}` : k)
    }
  }
  walk(doc, '')
  return out
}

export function AltTextBulkTool({options}: {options: AltTextOptions}) {
  const client = useClient({apiVersion: options.apiVersion ?? DEFAULT_API_VERSION})
  const schema = useSchema()
  const endpoint = options.endpoint ?? '/api/seo-ai'
  const types = useMemo(
    () =>
      options.documentTypes?.length
        ? options.documentTypes
        : schema.getTypeNames().filter((n) => {
            const t = schema.get(n) as {type?: {name?: string}} | undefined
            return t?.type?.name === 'document' && !n.startsWith('sanity.')
          }),
    [schema, options.documentTypes],
  )

  const [hits, setHits] = useState<ImageHit[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [status, setStatus] = useState<Status>('idle')
  const [progress, setProgress] = useState({done: 0, failed: 0})
  const [lastFailure, setLastFailure] = useState<string | null>(null)
  const [missingOnly, setMissingOnly] = useState(false)
  const cancelled = useRef(false)

  const load = useCallback(async () => {
    setHits(null)
    setError(null)
    setStatus('idle')
    try {
      const docs = await client.fetch<Array<Record<string, unknown>>>(
        `*[_type in $types && !(_id in path("drafts.**"))]`,
        {types},
      )
      const raw = docs.flatMap((doc) =>
        collectImages(doc).map((img) => ({
          docId: String(doc._id),
          docType: String(doc._type),
          docTitle: String(doc.title ?? doc.name ?? doc._id),
          ...img,
        })),
      )
      const refs = [...new Set(raw.map((r) => r.assetRef))]
      const assets = await client.fetch<Array<{_id: string; url: string}>>(
        `*[_id in $refs]{_id, url}`,
        {refs},
      )
      const urlById = new Map(assets.map((a) => [a._id, a.url]))
      setHits(
        raw
          .map((r) => ({...r, url: urlById.get(r.assetRef) ?? ''}))
          .filter((r) => r.url),
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }, [client, types])

  useEffect(() => {
    load()
  }, [load])

  const missing = useMemo(() => (hits ?? []).filter((h) => !h.alt?.trim()), [hits])
  const list = missingOnly ? missing : (hits ?? [])

  const run = useCallback(async () => {
    if (!missing.length) return
    cancelled.current = false
    setStatus('running')
    setProgress({done: 0, failed: 0})
    setLastFailure(null)
    const tx = client.transaction()
    let done = 0
    let failed = 0
    const batchSize = 4
    for (let i = 0; i < missing.length; i += batchSize) {
      if (cancelled.current) break
      const batch = missing.slice(i, i + batchSize)
      const results = await Promise.all(
        batch.map((h) =>
          requestSeoAi(endpoint, {task: 'alt', imageUrl: h.url, context: h.docTitle})
            .then((alt) => ({h, alt}))
            .catch((e: unknown) => ({h, alt: null as string | null, err: e instanceof Error ? e.message : String(e)})),
        ),
      )
      for (const {h, alt, ...rest} of results) {
        if (!alt) {
          failed++
          if ('err' in rest) setLastFailure(rest.err)
          continue
        }
        tx.patch(h.docId, (p) => p.set({[`${h.path}.alt`]: alt}))
        h.alt = alt
        done++
      }
      setProgress({done, failed})
    }
    if (done > 0) await tx.commit({autoGenerateArrayKeys: true})
    setStatus('done')
    setHits((prev) => (prev ? [...prev] : prev))
  }, [missing, client, endpoint])

  return (
    <Box padding={4}>
      <Container width={3}>
        <Flex direction="column" gap={4}>
          <Flex align="center" justify="space-between" gap={3} wrap="wrap">
            <Flex direction="column" gap={2}>
              <Heading as="h1" size={2}>
                Alt Text
              </Heading>
              <Text size={1} muted>
                Every image in a published document and its alt text. Generation fills the
                missing ones in one transaction; documents with open drafts keep their draft.
              </Text>
            </Flex>
            <Flex align="center" gap={2}>
              {hits && (
                <Badge tone={missing.length ? 'caution' : 'positive'} fontSize={1} padding={2}>
                  {missing.length} missing of {hits.length}
                </Badge>
              )}
              <Button
                text={missingOnly ? 'Show all' : 'Show missing only'}
                mode="ghost"
                onClick={() => setMissingOnly((s) => !s)}
              />
              <Button text="Refresh" mode="ghost" onClick={load} disabled={status === 'running'} />
              {status === 'running' ? (
                <Button
                  text={`Stop (${progress.done} done)`}
                  tone="critical"
                  onClick={() => {
                    cancelled.current = true
                  }}
                />
              ) : (
                <Button
                  text={`Generate ${missing.length} with AI`}
                  tone="primary"
                  disabled={!missing.length}
                  onClick={run}
                />
              )}
            </Flex>
          </Flex>

          {status === 'done' && (
            <Card tone={progress.failed ? 'caution' : 'positive'} padding={3} radius={2}>
              <Text size={1}>
                Wrote {progress.done} alt text{progress.done === 1 ? '' : 's'}
                {progress.failed ? `; ${progress.failed} failed.` : '.'}
                {lastFailure ? ` ${lastFailure}` : ''}
              </Text>
            </Card>
          )}
          {error && (
            <Card tone="critical" padding={3} radius={2}>
              <Text size={1}>{error}</Text>
            </Card>
          )}
          {!hits && !error && (
            <Flex justify="center" padding={5}>
              <Spinner />
            </Flex>
          )}

          <Flex direction="column" gap={2}>
            {list.map((h) => (
              <Card key={`${h.docId}:${h.path}`} padding={2} radius={2} border>
                <Flex align="center" gap={3}>
                  <img
                    src={`${h.url}?w=96&h=64&fit=crop&auto=format`}
                    alt=""
                    width={96}
                    height={64}
                    style={{objectFit: 'cover', borderRadius: 4, flex: 'none'}}
                  />
                  <Flex direction="column" gap={2} flex={1}>
                    <Text size={1} weight="medium">
                      <IntentLink
                        intent="edit"
                        params={{id: h.docId, type: h.docType}}
                        style={{color: 'inherit', textDecoration: 'none'}}
                      >
                        {h.docTitle}
                      </IntentLink>{' '}
                      <span style={{opacity: 0.6}}>· {h.path}</span>
                    </Text>
                    {h.alt?.trim() ? (
                      <Text size={1}>{h.alt}</Text>
                    ) : (
                      <Badge tone="caution" fontSize={0} style={{alignSelf: 'flex-start'}}>
                        no alt text
                      </Badge>
                    )}
                  </Flex>
                </Flex>
              </Card>
            ))}
          </Flex>
        </Flex>
      </Container>
    </Box>
  )
}
