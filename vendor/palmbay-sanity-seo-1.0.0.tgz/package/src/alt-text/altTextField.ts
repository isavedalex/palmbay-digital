import {defineField} from 'sanity'

import {AltTextInput, type AltTextInputOptions} from './AltTextInput'

/**
 * The alt-text fields to drop into any image type's `fields`:
 *
 *   defineField({name: 'image', type: 'image', fields: altTextFields()})
 *
 * Two fields: `alt`, and `isDecorative` — the escape hatch for images that
 * carry no information (dividers, background texture, an icon next to a
 * label that already says the same thing). A decorative image renders
 * `alt=""` so screen readers skip it; inventing a description for one is
 * worse than leaving it out.
 */
export function altTextFields(options: AltTextInputOptions & {required?: boolean} = {}) {
  const {required = true, ...inputOptions} = options
  return [
    defineField({
      name: 'isDecorative',
      title: 'Decorative image',
      type: 'boolean',
      initialValue: false,
      description:
        'Tick when the image adds no information a screen reader user would miss. It will be announced as decoration and needs no alt text.',
      options: {layout: 'checkbox'},
    }),
    defineField({
      name: 'alt',
      title: 'Alt text',
      type: 'string',
      description: 'Describe the image for screen readers and search engines.',
      components: {input: AltTextInput},
      options: inputOptions as Record<string, unknown>,
      hidden: ({parent}) => Boolean((parent as {isDecorative?: boolean} | undefined)?.isDecorative),
      validation: (rule) =>
        required
          ? rule.max(125).custom((value, context) => {
              const parent = context.parent as {isDecorative?: boolean} | undefined
              if (parent?.isDecorative) return true
              return value?.trim() ? true : 'Add alt text, or tick "Decorative image".'
            })
          : rule.max(125),
    }),
  ]
}

/**
 * Just the `alt` field, for schemas that don't want the decorative toggle.
 *
 * @deprecated Prefer {@link altTextFields}, which adds the decorative escape
 * hatch. Kept so existing schemas keep working unchanged.
 */
export function altTextField(options: AltTextInputOptions & {required?: boolean} = {}) {
  const {required = true, ...inputOptions} = options
  return defineField({
    name: 'alt',
    title: 'Alt text',
    type: 'string',
    description: 'Describe the image for screen readers and search engines.',
    components: {input: AltTextInput},
    options: inputOptions as Record<string, unknown>,
    validation: required ? (rule) => rule.required().max(125) : (rule) => rule.max(125),
  })
}
