import {defineField} from 'sanity'

import {AltTextInput, type AltTextInputOptions} from './AltTextInput'

/**
 * The `alt` string field to drop into any image type's `fields`:
 *
 *   defineField({name: 'image', type: 'image', fields: [altTextField()]})
 */
export function altTextField(options: AltTextInputOptions & {required?: boolean} = {}) {
  const {required = true, ...inputOptions} = options
  return defineField({
    name: 'alt',
    title: 'Alt text',
    type: 'string',
    description: 'Describe the image for screen readers and search engines.',
    components: {input: AltTextInput},
    options: inputOptions as Record<string, unknown>,
    validation: required ? (rule) => rule.required().max(125) : (rule) => rule.max(125),
  })
}
