import type {SanityImageRef} from '../shared/types'

/**
 * The `alt` to render for a Sanity image, honouring the decorative flag that
 * `altTextFields()` writes.
 *
 *   <img src={urlFor(image).url()} alt={imageAlt(image)} />
 *
 * A decorative image gets `alt=""` — the correct markup for something that
 * carries no information, so assistive tech skips it rather than reading a
 * filename. Returns `''` for a missing description too: an absent `alt`
 * attribute makes a screen reader announce the URL, which is worse than
 * silence. Despite living under `/next`, this is plain data — it works in
 * any framework.
 */
export function imageAlt(image: (SanityImageRef & {isDecorative?: boolean}) | null | undefined): string {
  if (!image || image.isDecorative) return ''
  return image.alt?.trim() ?? ''
}

/** True when the image still needs a description from an editor. */
export function needsAltText(
  image: (SanityImageRef & {isDecorative?: boolean}) | null | undefined,
): boolean {
  if (!image?.asset || image.isDecorative) return false
  return !image.alt?.trim()
}
