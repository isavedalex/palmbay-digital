import type {SanityImageRef, SeoFieldsValue} from '../shared/types'

/**
 * GROQ fragment that fetches everything `buildSeoMeta` needs, with image
 * assets dereferenced to URLs. Interpolate it into a projection:
 *
 *   `*[_type == "homePage"][0]{ title, ${seoProjection} }`
 */
export const seoProjection = `seo{
  title, description, keywords, focusKeyword, canonicalUrl,
  robots{noIndex, noFollow, noTranslate, noImageIndex},
  metaImage{alt, asset->{url, metadata{dimensions{width, height}}}},
  metaAttributes[]{key, type, value, image{asset->{url}}},
  hreflangs[]{locale, url},
  openGraph{url, title, description, siteName, type, imageType, imageUrl, image{alt, asset->{url, metadata{dimensions{width, height}}}}},
  twitter{card, site, creator, title, description, imageType, imageUrl, image{alt, asset->{url}}}
}`

/** Sitemap filter: `*[... && ${indexableFilter}]`. */
export const indexableFilter = `!(seo.robots.noIndex == true)`

export function isIndexable(seo: SeoFieldsValue | null | undefined): boolean {
  return seo?.robots?.noIndex !== true
}

/** Resolve a dereferenced (`asset->{url}`) or raw image to a URL. */
export type ImageUrlResolver = (image: SanityImageRef) => string | undefined

export interface BuildSeoMetaOptions {
  seo: SeoFieldsValue | null | undefined
  /** Site origin, no trailing slash. */
  baseUrl: string
  /** Path of this page, e.g. `/about`. Used for the canonical and og:url. */
  path?: string
  defaults?: {
    title?: string
    description?: string
    /** Absolute URL of the site-wide share image. */
    image?: string
    siteName?: string
    /** e.g. `@corkandcapture` */
    twitterSite?: string
  }
  /**
   * Turn a Sanity image into a URL. Defaults to the dereferenced `asset.url`
   * (which `seoProjection` provides). Pass `urlFor(img).width(1200).height(630).url()`
   * to get hotspot-aware crops.
   */
  imageUrlResolver?: ImageUrlResolver
}

const joinUrl = (base: string, path?: string) => {
  const b = base.replace(/\/+$/, '')
  if (!path || path === '/') return b || '/'
  return `${b}/${path.replace(/^\/+/, '')}`
}

const defaultResolver: ImageUrlResolver = (img) => img?.asset?.url

function pickImage(
  imageType: 'upload' | 'url' | undefined,
  image: SanityImageRef | undefined,
  imageUrl: string | undefined,
  resolve: ImageUrlResolver,
): {url: string; alt?: string; width?: number; height?: number} | undefined {
  if (imageType === 'url') return imageUrl ? {url: imageUrl} : undefined
  const url = image ? resolve(image) : undefined
  if (!url) return undefined
  const dims = (image?.asset as {metadata?: {dimensions?: {width?: number; height?: number}}})
    ?.metadata?.dimensions
  return {url, alt: image?.alt, width: dims?.width, height: dims?.height}
}

/**
 * Next.js `Metadata` object from an `seo` value. Import the `Metadata` type
 * from `next` in the caller; this returns a structurally compatible object so
 * the package has no hard dependency on `next`.
 *
 *   export async function generateMetadata() {
 *     const page = await client.fetch(`*[_type=="aboutPage"][0]{ ${seoProjection} }`)
 *     return buildSeoMeta({seo: page?.seo, baseUrl: SITE_URL, path: '/about', defaults: {...}})
 *   }
 */
export function buildSeoMeta({seo, baseUrl, path = '/', defaults = {}, imageUrlResolver}: BuildSeoMetaOptions) {
  const resolve = imageUrlResolver ?? defaultResolver
  const s = seo ?? {}
  const pageUrl = joinUrl(baseUrl, path)

  const title = s.title?.trim() || defaults.title
  const description = s.description?.trim() || defaults.description
  const canonical = s.canonicalUrl || pageUrl

  const metaImage = s.metaImage ? resolve(s.metaImage) : undefined
  const fallbackImage = metaImage ? {url: metaImage, alt: s.metaImage?.alt} : defaults.image ? {url: defaults.image} : undefined

  const og = s.openGraph ?? {}
  const ogImage = pickImage(og.imageType, og.image, og.imageUrl, resolve) ?? fallbackImage
  const tw = s.twitter ?? {}
  const twImage = pickImage(tw.imageType, tw.image, tw.imageUrl, resolve) ?? ogImage

  const robots = s.robots ?? {}
  const other: Record<string, string> = {}
  for (const attr of s.metaAttributes ?? []) {
    if (!attr.key) continue
    const value = attr.type === 'image' ? attr.image && resolve(attr.image) : attr.value
    if (value) other[attr.key] = value
  }
  const languages: Record<string, string> = {}
  for (const h of s.hreflangs ?? []) if (h.locale && h.url) languages[h.locale] = h.url

  return {
    title,
    description,
    keywords: s.keywords?.length ? s.keywords : undefined,
    alternates: {
      canonical,
      ...(Object.keys(languages).length ? {languages} : {}),
    },
    robots: {
      index: !robots.noIndex,
      follow: !robots.noFollow,
      ...(robots.noTranslate ? {notranslate: true} : {}),
      ...(robots.noImageIndex ? {noimageindex: true} : {}),
      googleBot: {
        index: !robots.noIndex,
        follow: !robots.noFollow,
        ...(robots.noImageIndex ? {noimageindex: true} : {}),
      },
    },
    openGraph: {
      type: (og.type as 'website' | 'article' | undefined) ?? 'website',
      url: og.url || canonical,
      title: og.title?.trim() || title,
      description: og.description?.trim() || description,
      siteName: og.siteName || defaults.siteName,
      images: ogImage ? [ogImage] : undefined,
    },
    twitter: {
      card: tw.card ?? 'summary_large_image',
      site: tw.site || defaults.twitterSite,
      creator: tw.creator,
      title: tw.title?.trim() || og.title?.trim() || title,
      description: tw.description?.trim() || og.description?.trim() || description,
      images: twImage ? [twImage.url] : undefined,
    },
    ...(Object.keys(other).length ? {other} : {}),
  }
}

export type SeoMetadata = ReturnType<typeof buildSeoMeta>
