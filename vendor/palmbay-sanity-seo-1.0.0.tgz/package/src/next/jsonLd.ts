/**
 * Schema.org JSON-LD builders for the objects a local-business site needs.
 * Each returns a plain object; render with `<JsonLd data={...} />`.
 */

type JsonLd = Record<string, unknown>

const clean = <T extends JsonLd>(obj: T): T => {
  for (const k of Object.keys(obj)) {
    const v = obj[k]
    if (v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0)) delete obj[k]
  }
  return obj
}

export interface PostalAddress {
  streetAddress?: string
  addressLocality?: string
  addressRegion?: string
  postalCode?: string
  addressCountry?: string
}

export interface OpeningHours {
  /** e.g. ['Monday','Tuesday'] */
  dayOfWeek: string[]
  /** 'HH:MM' 24h */
  opens: string
  closes: string
}

export interface LocalBusinessInput {
  /** Specific type, e.g. 'Photographer', 'Plumber', 'GeneralContractor'. Default 'LocalBusiness'. */
  type?: string
  name: string
  url: string
  /** Absolute URL of the logo or a representative photo. */
  image?: string | string[]
  logo?: string
  description?: string
  telephone?: string
  email?: string
  priceRange?: string
  address?: PostalAddress
  geo?: {latitude: number; longitude: number}
  /** Towns / counties served. */
  areaServed?: string[]
  openingHours?: OpeningHours[]
  /** Social + directory profiles. */
  sameAs?: string[]
  aggregateRating?: {ratingValue: number; reviewCount: number}
}

export function localBusinessJsonLd(input: LocalBusinessInput): JsonLd {
  return clean({
    '@context': 'https://schema.org',
    '@type': input.type ?? 'LocalBusiness',
    '@id': `${input.url.replace(/\/+$/, '')}/#business`,
    name: input.name,
    url: input.url,
    image: input.image,
    logo: input.logo,
    description: input.description,
    telephone: input.telephone,
    email: input.email,
    priceRange: input.priceRange,
    address: input.address ? clean({'@type': 'PostalAddress', ...input.address}) : undefined,
    geo: input.geo ? {'@type': 'GeoCoordinates', ...input.geo} : undefined,
    areaServed: input.areaServed?.map((name) => ({'@type': 'Place', name})),
    openingHoursSpecification: input.openingHours?.map((h) => ({
      '@type': 'OpeningHoursSpecification',
      ...h,
    })),
    sameAs: input.sameAs,
    aggregateRating: input.aggregateRating
      ? {
          '@type': 'AggregateRating',
          ratingValue: input.aggregateRating.ratingValue,
          reviewCount: input.aggregateRating.reviewCount,
          bestRating: 5,
          worstRating: 1,
        }
      : undefined,
  })
}

export function organizationJsonLd(input: {
  name: string
  url: string
  logo?: string
  sameAs?: string[]
  contactPoint?: {telephone: string; contactType?: string; email?: string}
}): JsonLd {
  return clean({
    '@context': 'https://schema.org',
    '@type': 'Organization',
    '@id': `${input.url.replace(/\/+$/, '')}/#organization`,
    name: input.name,
    url: input.url,
    logo: input.logo,
    sameAs: input.sameAs,
    contactPoint: input.contactPoint
      ? clean({'@type': 'ContactPoint', contactType: 'customer service', ...input.contactPoint})
      : undefined,
  })
}

export function webSiteJsonLd(input: {name: string; url: string; searchUrlTemplate?: string}): JsonLd {
  return clean({
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: input.name,
    url: input.url,
    potentialAction: input.searchUrlTemplate
      ? {
          '@type': 'SearchAction',
          target: {'@type': 'EntryPoint', urlTemplate: input.searchUrlTemplate},
          'query-input': 'required name=search_term_string',
        }
      : undefined,
  })
}

export function articleJsonLd(input: {
  /** 'Article' | 'BlogPosting' | 'NewsArticle' */
  type?: string
  headline: string
  description?: string
  url: string
  image?: string | string[]
  datePublished: string
  dateModified?: string
  author: {name: string; url?: string}
  publisher: {name: string; logo?: string}
}): JsonLd {
  return clean({
    '@context': 'https://schema.org',
    '@type': input.type ?? 'BlogPosting',
    mainEntityOfPage: {'@type': 'WebPage', '@id': input.url},
    headline: input.headline,
    description: input.description,
    image: input.image,
    datePublished: input.datePublished,
    dateModified: input.dateModified ?? input.datePublished,
    author: clean({'@type': 'Person', ...input.author}),
    publisher: clean({
      '@type': 'Organization',
      name: input.publisher.name,
      logo: input.publisher.logo ? {'@type': 'ImageObject', url: input.publisher.logo} : undefined,
    }),
  })
}

export function serviceJsonLd(input: {
  name: string
  description?: string
  url?: string
  serviceType?: string
  areaServed?: string[]
  provider: {name: string; url: string}
  offers?: {price?: string; priceCurrency?: string}
}): JsonLd {
  return clean({
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: input.name,
    description: input.description,
    url: input.url,
    serviceType: input.serviceType,
    areaServed: input.areaServed?.map((name) => ({'@type': 'Place', name})),
    provider: {'@type': 'LocalBusiness', name: input.provider.name, url: input.provider.url},
    offers: input.offers ? clean({'@type': 'Offer', ...input.offers}) : undefined,
  })
}

export function personJsonLd(input: {
  name: string
  url?: string
  image?: string
  jobTitle?: string
  description?: string
  worksFor?: {name: string; url?: string}
  sameAs?: string[]
}): JsonLd {
  return clean({
    '@context': 'https://schema.org',
    '@type': 'Person',
    name: input.name,
    url: input.url,
    image: input.image,
    jobTitle: input.jobTitle,
    description: input.description,
    worksFor: input.worksFor ? clean({'@type': 'Organization', ...input.worksFor}) : undefined,
    sameAs: input.sameAs,
  })
}

export function faqPageJsonLd(items: Array<{question: string; answer: string}>): JsonLd {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((i) => ({
      '@type': 'Question',
      name: i.question,
      acceptedAnswer: {'@type': 'Answer', text: i.answer},
    })),
  }
}

export function breadcrumbJsonLd(items: Array<{name: string; url: string}>): JsonLd {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  }
}
