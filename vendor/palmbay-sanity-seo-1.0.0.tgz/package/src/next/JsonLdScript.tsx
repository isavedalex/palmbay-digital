/**
 * Renders one or more JSON-LD objects. Server-component safe (no hooks).
 * `<` is escaped so a value containing `</script>` cannot break out.
 */
export function JsonLd({data}: {data: Record<string, unknown> | Array<Record<string, unknown>>}) {
  const json = JSON.stringify(data).replace(/</g, '\\u003c')
  return <script type="application/ld+json" dangerouslySetInnerHTML={{__html: json}} />
}
