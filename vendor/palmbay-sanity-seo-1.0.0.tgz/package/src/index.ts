/**
 * @palmbay/sanity-seo — Studio entry.
 *
 *   import {seoFields, requiredSeo, openSeo, altText, altTextFields} from '@palmbay/sanity-seo'
 *
 * Also: `@palmbay/sanity-seo/next` (metadata + JSON-LD for the site),
 * `@palmbay/sanity-seo/server` (the AI route handler, Node only) and
 * `@palmbay/sanity-seo/onboarding` (tours; needs sanity-plugin-editor-onboarding).
 */
export {
  seoFields,
  seoSchemaTypes,
  seoFieldsType,
  requiredSeo,
  requiredSeoCheck,
  scoreSeo,
  bandFor,
  type SeoFieldsOptions,
  type SeoHealthResult,
  type SeoHealthBand,
} from './seo-fields'
export {openSeo, type OpenSeoOptions} from './open-seo'
export {
  altText,
  altTextField,
  altTextFields,
  AltTextInput,
  type AltTextOptions,
  type AltTextInputOptions,
} from './alt-text'
export type {
  SeoFieldsValue,
  SeoRobots,
  SeoOpenGraph,
  SeoTwitter,
  SeoMetaAttribute,
  SeoHreflang,
  SanityImageRef,
  SeoAiRequest,
  SeoAiResponse,
} from './shared/types'
export {SEO_LIMITS} from './shared/types'
