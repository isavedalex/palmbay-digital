import {definePlugin} from 'sanity'
import {OpenSeoIcon} from './OpenSeoIcon'
import {OpenSeoTool} from './OpenSeoTool'

/**
 * Configuration for {@link openSeo}.
 *
 * @public
 */
export interface OpenSeoOptions {
  /**
   * Full OpenSEO share-link URL, e.g.
   * `https://seo.example.com/embed/oseo_share_xxx`. Read it from an env var
   * rather than hardcoding it, so the token can be rotated without a code
   * change.
   */
  embedUrl?: string
  /** Studio tool name (the `/<name>` segment in the studio URL). */
  name?: string
  /** Label shown in the studio navbar. */
  title?: string
}

/**
 * Adds a top-level studio tab showing a read-only OpenSEO snapshot for one
 * project — rank tracking, site audit, and top page opportunities.
 *
 * The share link is the only credential: it is unguessable, read-only, scoped
 * to a single project, and revocable from OpenSEO. Anyone who can open this
 * studio can read the token out of the iframe's `src`, which is the intended
 * trust model (it grants no more than the tab already shows), but it does mean
 * the link should be revoked when studio access is revoked.
 *
 * @public
 */
export const openSeo = definePlugin<OpenSeoOptions | void>((options) => {
  const {embedUrl, name = 'rank-tracking', title = 'Rank Tracking'} = options ?? {}

  return {
    name: '@palmbay/sanity-seo/open-seo',
    tools: [
      {
        name,
        title,
        icon: OpenSeoIcon,
        component: function OpenSeoToolPane() {
          return <OpenSeoTool embedUrl={embedUrl} title={`${title} snapshot`} />
        },
      },
    ],
  }
})
