import type {CSSProperties} from 'react'

/**
 * The embed URL is supplied by the host studio at build time (typically a
 * SANITY_STUDIO_* env var). When it is missing or malformed the iframe would
 * otherwise render as a silent blank rectangle that looks exactly like
 * "OpenSEO is down" — so validate it up front and name the real problem in
 * the pane instead.
 */
function describeProblem(embedUrl: string | undefined): string | null {
  if (!embedUrl) {
    return 'No embedUrl was passed to openSeo(). The environment variable it reads is probably unset in this build.'
  }

  let url: URL
  try {
    url = new URL(embedUrl)
  } catch {
    return `embedUrl is not a valid URL: "${embedUrl}"`
  }

  if (url.protocol !== 'https:' && url.hostname !== 'localhost') {
    return 'embedUrl must be an https:// URL (http is allowed only for localhost).'
  }
  if (!url.pathname.startsWith('/embed/')) {
    return 'embedUrl must point at an OpenSEO share link, whose path looks like /embed/<token>.'
  }
  return null
}

// Plain inline styles, inheriting `color` from the Studio, so the notice reads
// correctly in both Studio themes without depending on @sanity/ui (whose major
// version also tracks the Studio major).
const wrapperStyle: CSSProperties = {height: '100%', minHeight: 480}

const frameStyle: CSSProperties = {
  display: 'block',
  border: 0,
  width: '100%',
  height: '100%',
}

const noticeStyle: CSSProperties = {
  margin: 24,
  padding: '20px 22px',
  maxWidth: 640,
  border: '1px solid currentColor',
  borderRadius: 6,
  opacity: 0.85,
  font: '14px/1.55 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif',
}

const codeStyle: CSSProperties = {
  display: 'block',
  marginTop: 12,
  padding: 12,
  whiteSpace: 'pre',
  overflowX: 'auto',
  border: '1px solid currentColor',
  borderRadius: 4,
  font: '12px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace',
  opacity: 0.9,
}

function SetupNotice({problem}: {problem: string}) {
  return (
    <div style={noticeStyle}>
      <strong>OpenSEO is not configured for this studio.</strong>
      <p style={{margin: '10px 0 0'}}>{problem}</p>
      <p style={{margin: '14px 0 0'}}>
        Create a read-only share link in OpenSEO under{' '}
        <em>Project → Settings → Sharing</em>, then pass the URL it reveals:
      </p>
      <code style={codeStyle}>
        {`openSeo({\n  embedUrl: process.env.NEXT_PUBLIC_OPENSEO_EMBED_URL,\n})`}
      </code>
      <p style={{margin: '14px 0 0'}}>
        Use a <code>NEXT_PUBLIC_*</code> variable for a studio embedded in a
        Next.js app, or <code>SANITY_STUDIO_*</code> for a standalone studio
        built with the Sanity CLI — only those prefixes reach the browser.
      </p>
    </div>
  )
}

export function OpenSeoTool({embedUrl, title}: {embedUrl?: string; title: string}) {
  const problem = describeProblem(embedUrl)
  if (problem) return <SetupNotice problem={problem} />

  return (
    <div style={wrapperStyle}>
      {/*
        No sandbox attribute: the embed page is script-free, static HTML from
        a host we control, and sandboxing buys nothing here. referrerPolicy is
        set so the studio's own URL is never sent to the OpenSEO host.
      */}
      <iframe
        src={embedUrl}
        title={title}
        referrerPolicy="no-referrer"
        loading="lazy"
        style={frameStyle}
      />
    </div>
  )
}
