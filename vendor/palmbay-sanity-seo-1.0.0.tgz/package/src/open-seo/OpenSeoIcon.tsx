/**
 * Inline SVG rather than an import from @sanity/icons: that package's major
 * version tracks the Studio major, and these studios span sanity v4 to v6
 * (see the workspace's sanity v5-vs-v6 split). A 12-line SVG keeps this
 * plugin installable in all of them with no peer-version negotiation.
 */
export function OpenSeoIcon() {
  return (
    <svg
      width="1em"
      height="1em"
      viewBox="0 0 25 25"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      data-sanity-icon="openseo"
      aria-hidden="true"
    >
      <circle cx="11" cy="11" r="6" />
      <path d="M15.5 15.5 L20 20" />
      <path d="M8.5 12.5 L10.5 10 L12.5 11.5 L14 8.5" />
    </svg>
  )
}
