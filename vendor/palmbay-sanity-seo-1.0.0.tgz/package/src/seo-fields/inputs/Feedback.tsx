import {Flex, Text} from '@sanity/ui'

export type FeedbackTone = 'positive' | 'caution' | 'critical'

const COLORS: Record<FeedbackTone, string> = {
  positive: '#2e9e5b',
  caution: '#e0a300',
  critical: '#d9442d',
}

export function FeedbackLine({tone, children}: {tone: FeedbackTone; children: string}) {
  return (
    <Flex align="center" gap={2}>
      <span
        aria-hidden
        style={{
          width: 8,
          height: 8,
          minWidth: 8,
          borderRadius: '50%',
          background: COLORS[tone],
          display: 'inline-block',
        }}
      />
      <Text size={1} muted>
        {children}
      </Text>
    </Flex>
  )
}

export function lengthFeedback(
  label: string,
  length: number,
  min: number,
  max: number,
): {tone: FeedbackTone; text: string} {
  if (length === 0) return {tone: 'critical', text: `${label} is empty`}
  if (length < min) return {tone: 'caution', text: `${length}/${max} — a little short (aim for ${min}–${max})`}
  if (length > max) return {tone: 'critical', text: `${length}/${max} — too long, will be cut off`}
  return {tone: 'positive', text: `${length}/${max} — good length`}
}
