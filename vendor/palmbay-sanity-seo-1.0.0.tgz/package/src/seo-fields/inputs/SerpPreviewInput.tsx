import {Box, Card, Flex, Text} from '@sanity/ui'
import type {CSSProperties} from 'react'
import type {StringInputProps} from 'sanity'

import {SEO_LIMITS} from '../../shared/types'
import {useSeoInputContext, type SeoInputOptions} from './useSeoInputContext'

const truncate = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1).trimEnd()}…` : s)

// Google's own SERP colours, fixed regardless of Studio theme: the point is
// to look like the search result, not like the Studio.
const serp: Record<string, CSSProperties> = {
  wrap: {
    background: '#fff',
    border: '1px solid #dadce0',
    borderRadius: 8,
    padding: 16,
    maxWidth: 600,
    fontFamily: 'Arial, Helvetica, sans-serif',
  },
  url: {margin: 0, color: '#202124', fontSize: 12, lineHeight: 1.4, wordBreak: 'break-all'},
  domain: {color: '#4d5156'},
  title: {
    margin: '4px 0 6px',
    color: '#1a0dab',
    fontSize: 20,
    fontWeight: 400,
    lineHeight: 1.3,
    wordBreak: 'break-word',
  },
  suffix: {color: '#70757a'},
  desc: {
    margin: 0,
    color: '#4d5156',
    fontSize: 14,
    lineHeight: 1.58,
    wordBreak: 'break-word',
    display: '-webkit-box',
    WebkitLineClamp: 2,
    WebkitBoxOrient: 'vertical',
    overflow: 'hidden',
  },
}

export function SerpPreviewInput(props: StringInputProps) {
  const options = props.schemaType.options as SeoInputOptions | undefined
  const {seo, rootDoc, titleSuffix} = useSeoInputContext(props.path, options)

  const base = (
    seo.canonicalUrl ||
    options?.baseUrl ||
    (typeof location !== 'undefined' ? location.origin : 'https://www.example.com')
  ).replace(/\/+$/, '')
  const slug = String((rootDoc.slug as {current?: string} | undefined)?.current ?? '').replace(
    /^\/+/,
    '',
  )
  const finalUrl = seo.canonicalUrl ? base : slug ? `${base}/${slug}` : base
  let host = 'example.com'
  try {
    host = new URL(finalUrl).hostname
  } catch {
    /* keep placeholder */
  }
  const crumbs = finalUrl.replace(/^https?:\/\/[^/]+/, '').split('/').filter(Boolean)

  const titleMax = SEO_LIMITS.title.max - (titleSuffix ? titleSuffix.length + 3 : 0)
  const title = seo.title?.trim()
  const description = seo.description?.trim()

  return (
    <Card padding={3} radius={2} tone="transparent" border>
      <Flex direction="column" gap={3}>
        <Text size={1} muted weight="medium">
          Google search preview
        </Text>
        <Box style={serp.wrap}>
          <p style={serp.url}>
            <span style={serp.domain}>{host}</span>
            {crumbs.map((c) => (
              <span key={c}> › {c}</span>
            ))}
          </p>
          <h3 style={serp.title}>
            {title ? truncate(title, Math.max(1, titleMax)) : 'Your meta title will appear here'}
            {titleSuffix && <span style={serp.suffix}> | {titleSuffix}</span>}
          </h3>
          <p style={serp.desc}>
            {description
              ? truncate(description, SEO_LIMITS.description.max)
              : 'Your meta description will show here. Make it compelling.'}
          </p>
        </Box>
      </Flex>
    </Card>
  )
}
