import {Flex} from '@sanity/ui'
import {useCallback, useEffect, useState} from 'react'
import {PatchEvent, set, type StringInputProps} from 'sanity'

import {extractDocText} from '../../shared/extractText'
import {SEO_LIMITS} from '../../shared/types'
import {AiDraftButton} from './AiDraftButton'
import {FeedbackLine, lengthFeedback} from './Feedback'
import {useSeoInputContext, type SeoInputOptions} from './useSeoInputContext'

export function MetaTitleInput(props: StringInputProps) {
  const {value = '', renderDefault, path, schemaType, onChange} = props
  const options = schemaType.options as SeoInputOptions | undefined
  const {seo, rootDoc, client, titleSuffix, pagePath} = useSeoInputContext(path, options)

  // ` | Brand` is appended by the site layout, so it eats into the 60 chars.
  const suffixLen = titleSuffix ? titleSuffix.length + 3 : 0
  const max = SEO_LIMITS.title.max - suffixLen
  const feedback = lengthFeedback('Title', value.length, SEO_LIMITS.title.min - suffixLen, max)

  const [duplicate, setDuplicate] = useState(false)
  const docId = String(rootDoc._id ?? '').replace(/^drafts\./, '')
  useEffect(() => {
    if (!value.trim() || !docId) {
      setDuplicate(false)
      return
    }
    const t = setTimeout(() => {
      client
        .fetch<number>(
          `count(*[seo.title == $title && !(_id in [$id, "drafts." + $id]) && !(_id in path("drafts.**"))])`,
          {title: value, id: docId},
        )
        .then((n) => setDuplicate(n > 0))
        .catch(() => setDuplicate(false))
    }, 600)
    return () => clearTimeout(t)
  }, [value, docId, client])

  const buildRequest = useCallback(() => {
    const text = extractDocText(rootDoc)
    if (!text) return null
    return {task: 'title' as const, text, pagePath, focusKeyword: seo.focusKeyword, siteName: titleSuffix}
  }, [rootDoc, seo.focusKeyword, titleSuffix, pagePath])

  return (
    <Flex direction="column" gap={3}>
      {renderDefault(props)}
      <Flex direction="column" gap={2}>
        <FeedbackLine tone={feedback.tone}>{feedback.text}</FeedbackLine>
        {duplicate && (
          <FeedbackLine tone="caution">
            Another published page already uses this exact title.
          </FeedbackLine>
        )}
        {titleSuffix && value.toLowerCase().includes(titleSuffix.toLowerCase()) && (
          <FeedbackLine tone="caution">
            {`Leave out "${titleSuffix}" — the site appends it automatically.`}
          </FeedbackLine>
        )}
      </Flex>
      <AiDraftButton
        endpoint={options?.aiEndpoint}
        label="Draft title with AI"
        buildRequest={buildRequest}
        onResult={(v) => onChange(PatchEvent.from(set(v)))}
      />
    </Flex>
  )
}
