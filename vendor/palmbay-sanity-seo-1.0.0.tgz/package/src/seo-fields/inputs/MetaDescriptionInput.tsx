import {Flex} from '@sanity/ui'
import {useCallback} from 'react'
import {PatchEvent, set, type StringInputProps} from 'sanity'

import {extractDocText} from '../../shared/extractText'
import {SEO_LIMITS} from '../../shared/types'
import {AiDraftButton} from './AiDraftButton'
import {FeedbackLine, lengthFeedback} from './Feedback'
import {useSeoInputContext, type SeoInputOptions} from './useSeoInputContext'

export function MetaDescriptionInput(props: StringInputProps) {
  const {value = '', renderDefault, path, schemaType, onChange} = props
  const options = schemaType.options as SeoInputOptions | undefined
  const {seo, rootDoc, titleSuffix, pagePath} = useSeoInputContext(path, options)

  const feedback = lengthFeedback(
    'Description',
    value.length,
    SEO_LIMITS.description.min,
    SEO_LIMITS.description.max,
  )
  const fk = seo.focusKeyword?.trim().toLowerCase()
  const missingKeyword = fk && value && !value.toLowerCase().includes(fk)

  const buildRequest = useCallback(() => {
    const text = extractDocText(rootDoc)
    if (!text) return null
    return {
      task: 'description' as const,
      text,
      pagePath,
      focusKeyword: seo.focusKeyword,
      siteName: titleSuffix,
    }
  }, [rootDoc, seo.focusKeyword, titleSuffix, pagePath])

  return (
    <Flex direction="column" gap={3}>
      {renderDefault(props)}
      <Flex direction="column" gap={2}>
        <FeedbackLine tone={feedback.tone}>{feedback.text}</FeedbackLine>
        {missingKeyword && (
          <FeedbackLine tone="caution">{`Focus keyword "${seo.focusKeyword}" is not mentioned.`}</FeedbackLine>
        )}
      </Flex>
      <AiDraftButton
        endpoint={options?.aiEndpoint}
        label="Draft description with AI"
        buildRequest={buildRequest}
        onResult={(v) => onChange(PatchEvent.from(set(v)))}
      />
    </Flex>
  )
}
