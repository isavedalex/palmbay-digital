import {useEffect, useMemo, useState} from 'react'
import {useClient, useFormValue, type Path} from 'sanity'

import type {SeoFieldsValue} from '../../shared/types'
import {DEFAULT_API_VERSION} from '../options'

export interface SeoInputOptions {
  apiVersion?: string
  baseUrl?: string
  titleSuffix?: string
  titleSuffixQuery?: string
  aiEndpoint?: string | null
}

/**
 * Everything the field inputs share: the parent `seo` object, the root
 * document, and the resolved brand suffix (static or from GROQ).
 */
export function useSeoInputContext(path: Path, options: SeoInputOptions | undefined) {
  const seoPath = useMemo(() => path.slice(0, -1), [path])
  const seo = (useFormValue(seoPath) as SeoFieldsValue | undefined) ?? {}
  const rootDoc = (useFormValue([]) as Record<string, unknown> | undefined) ?? {}
  const client = useClient({apiVersion: options?.apiVersion ?? DEFAULT_API_VERSION})

  const [querySuffix, setQuerySuffix] = useState('')
  const query = options?.titleSuffixQuery
  useEffect(() => {
    if (!query) return
    let live = true
    client
      .fetch<string | null>(query)
      .then((r) => live && setQuerySuffix(r ? String(r) : ''))
      .catch(() => live && setQuerySuffix(''))
    return () => {
      live = false
    }
  }, [query, client])

  const titleSuffix = query ? querySuffix : (options?.titleSuffix ?? '')

  // The site path this document renders at, so the AI route can look up the
  // queries Search Console attributes to this page specifically.
  const slug = (rootDoc.slug as {current?: string} | undefined)?.current
  const pagePath = slug ? (slug === '/' ? '/' : `/${slug.replace(/^\/+/, '')}`) : undefined

  return {seo, rootDoc, client, titleSuffix, pagePath, seoPath}
}
