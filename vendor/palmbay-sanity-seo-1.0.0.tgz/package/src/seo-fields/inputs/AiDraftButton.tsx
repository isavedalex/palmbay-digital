import {Button, Flex, Text} from '@sanity/ui'
import {useCallback, useState} from 'react'

import type {SeoAiRequest, SeoAiResponse} from '../../shared/types'

export async function requestSeoAi(endpoint: string, body: SeoAiRequest): Promise<string> {
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {'content-type': 'application/json'},
    body: JSON.stringify(body),
  })
  if (!res.ok) {
    const detail = await res.text().catch(() => '')
    throw new Error(detail || `AI request failed (${res.status})`)
  }
  const json = (await res.json()) as SeoAiResponse
  if (!json?.result) throw new Error('AI returned an empty result')
  return json.result
}

export function AiDraftButton({
  endpoint,
  label,
  buildRequest,
  onResult,
}: {
  endpoint: string | null | undefined
  label: string
  buildRequest: () => SeoAiRequest | null
  onResult: (value: string) => void
}) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const run = useCallback(async () => {
    if (!endpoint) return
    const body = buildRequest()
    if (!body) {
      setError('Add some page content first so there is something to draft from.')
      return
    }
    setBusy(true)
    setError(null)
    try {
      onResult(await requestSeoAi(endpoint, body))
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(false)
    }
  }, [endpoint, buildRequest, onResult])

  if (!endpoint) return null
  return (
    <Flex align="center" gap={3}>
      <Button
        mode="ghost"
        tone="primary"
        fontSize={1}
        padding={2}
        text={busy ? 'Drafting…' : label}
        disabled={busy}
        onClick={run}
      />
      {error && (
        <Text size={1} muted>
          {error}
        </Text>
      )}
    </Flex>
  )
}
