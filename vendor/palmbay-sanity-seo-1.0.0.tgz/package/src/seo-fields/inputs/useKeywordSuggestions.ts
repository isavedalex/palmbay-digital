import {useCallback, useState} from 'react'

import type {KeywordSuggestion, SeoAiKeywordResponse} from '../../shared/types'

/**
 * Asks the AI route which focus keyword this page should target. The route
 * reads the OpenSEO snapshot, so the suggestions are anchored to positions
 * and Search Console impressions rather than guessed from the copy.
 */
export function useKeywordSuggestions(endpoint: string | null | undefined) {
  const [suggestions, setSuggestions] = useState<KeywordSuggestion[] | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const suggest = useCallback(
    async (body: {text: string; pagePath?: string; siteName?: string}) => {
      if (!endpoint) return
      if (!body.text.trim()) {
        setError('Add some page content first so there is something to work from.')
        return
      }
      setBusy(true)
      setError(null)
      try {
        const res = await fetch(endpoint, {
          method: 'POST',
          headers: {'content-type': 'application/json'},
          body: JSON.stringify({task: 'keyword', ...body}),
        })
        const text = await res.text()
        if (!res.ok) {
          let message = text
          try {
            message = (JSON.parse(text) as {error?: string}).error ?? text
          } catch {
            // not JSON
          }
          throw new Error(message || `Keyword request failed (${res.status})`)
        }
        setSuggestions((JSON.parse(text) as SeoAiKeywordResponse).suggestions ?? [])
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e))
      } finally {
        setBusy(false)
      }
    },
    [endpoint],
  )

  return {suggestions, busy, error, suggest, clear: () => setSuggestions(null)}
}

/** "pos 7 · 240 impressions/mo" — only the numbers we actually have. */
export function describeSuggestion(s: KeywordSuggestion): string {
  const bits: string[] = []
  if (s.position != null) bits.push(`pos ${Math.round(s.position)}`)
  if (s.impressions != null) bits.push(`${s.impressions} impressions/28d`)
  if (s.searchVolume != null) bits.push(`${s.searchVolume} searches/mo`)
  return bits.join(' · ')
}
