import {SEO_LIMITS, type SeoFieldsValue} from '../shared/types'

export type SeoHealthBand = 'excellent' | 'good' | 'fair' | 'poor' | 'missing'

export interface SeoHealthResult {
  /** 0–100 */
  score: number
  band: SeoHealthBand
  issues: string[]
}

const hasImage = (img?: {asset?: {_ref?: string; url?: string}}): boolean =>
  Boolean(img?.asset?._ref || img?.asset?.url)

const norm = (s: string) => s.toLowerCase().replace(/\s+/g, ' ').trim()

/**
 * Pure completeness/length scoring for one `seo` object. Deliberately simple
 * and deterministic so the Health tool, the publish validator and the tests
 * all agree on a number. Weights sum to 100.
 */
export function scoreSeo(seo: SeoFieldsValue | null | undefined): SeoHealthResult {
  if (!seo || Object.keys(seo).filter((k) => !k.startsWith('_')).length === 0) {
    return {score: 0, band: 'missing', issues: ['No SEO fields set']}
  }

  const issues: string[] = []
  let score = 0

  // Title — 25
  const title = seo.title?.trim() ?? ''
  if (!title) issues.push('Missing meta title')
  else if (title.length < SEO_LIMITS.title.min) {
    score += 15
    issues.push(`Meta title short (< ${SEO_LIMITS.title.min} chars)`)
  } else if (title.length > SEO_LIMITS.title.max) {
    score += 15
    issues.push(`Meta title long (> ${SEO_LIMITS.title.max} chars, will be cut off)`)
  } else score += 25

  // Description — 25
  const description = seo.description?.trim() ?? ''
  if (!description) issues.push('Missing meta description')
  else if (description.length < SEO_LIMITS.description.min) {
    score += 15
    issues.push(`Meta description short (< ${SEO_LIMITS.description.min} chars)`)
  } else if (description.length > SEO_LIMITS.description.max) {
    score += 15
    issues.push(`Meta description long (> ${SEO_LIMITS.description.max} chars)`)
  } else score += 25

  // Meta image — 20 (a real OG image URL/upload also counts)
  const ogHasImage =
    seo.openGraph?.imageType === 'url'
      ? Boolean(seo.openGraph?.imageUrl)
      : hasImage(seo.openGraph?.image)
  if (hasImage(seo.metaImage) || ogHasImage) score += 20
  else issues.push('Missing meta / social share image')

  // Focus keyword — 15
  const fk = seo.focusKeyword?.trim()
  if (!fk) issues.push('No focus keyword')
  else {
    const inTitle = norm(title).includes(norm(fk))
    const inDesc = norm(description).includes(norm(fk))
    if (inTitle && inDesc) score += 15
    else if (inTitle || inDesc) {
      score += 8
      issues.push(`Focus keyword not in ${inTitle ? 'description' : 'title'}`)
    } else issues.push('Focus keyword not used in title or description')
  }

  // Open Graph overrides — 10 (optional polish; site defaults usually cover it)
  if (seo.openGraph?.title || seo.openGraph?.description) score += 10
  else issues.push('No Open Graph title/description override (falls back to meta)')

  // Canonical — 5
  if (seo.canonicalUrl) score += 5

  return {score, band: bandFor(score), issues}
}

export function bandFor(score: number): SeoHealthBand {
  if (score >= 85) return 'excellent'
  if (score >= 65) return 'good'
  if (score >= 40) return 'fair'
  if (score > 0) return 'poor'
  return 'missing'
}
