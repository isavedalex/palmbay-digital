import {definePlugin} from 'sanity'

import {SeoHealthIcon} from './SeoHealthIcon'
import {SeoHealthTool} from './SeoHealthTool'
import {seoSchemaTypes} from './schema'
import type {SeoFieldsOptions} from './options'

export type {SeoFieldsOptions} from './options'
export {scoreSeo, bandFor, type SeoHealthResult, type SeoHealthBand} from './score'
export {requiredSeo, requiredSeoCheck} from './validation'
export {seoSchemaTypes, seoFieldsType} from './schema'

/**
 * Registers the `seoFields` object type (plus `robots`, `openGraph`,
 * `twitter`, `metaAttribute`, `hreflangEntry`) and the "SEO Health" tool.
 *
 *   plugins: [seoFields({titleSuffix: 'Cork & Capture'})]
 *   // on every page type:
 *   defineField({name: 'seo', type: 'seoFields', validation: requiredSeo})
 */
export const seoFields = definePlugin<SeoFieldsOptions | void>((options) => {
  const opts: SeoFieldsOptions = options ?? {}
  return {
    name: '@palmbay/sanity-seo/seo-fields',
    schema: {types: seoSchemaTypes(opts)},
    tools:
      opts.healthTool === false
        ? []
        : [
            {
              name: 'seo-health',
              title: 'SEO Health',
              icon: SeoHealthIcon,
              component: function SeoHealthToolPane() {
                return <SeoHealthTool options={opts} />
              },
            },
          ],
  }
})
