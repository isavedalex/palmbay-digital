/**
 * Schema types. Field names, types and defaults match sanity-plugin-seofields
 * v1.x (MIT, © Desai Hardik) so documents written by that plugin load here
 * unchanged. The licence / field-override / grouping plumbing was dropped.
 */
import {defineField, defineType, type SchemaTypeDefinition} from 'sanity'

import {MetaDescriptionInput} from '../inputs/MetaDescriptionInput'
import {MetaTitleInput} from '../inputs/MetaTitleInput'
import {SerpPreviewInput} from '../inputs/SerpPreviewInput'
import {DEFAULT_API_VERSION, resolveAiEndpoint, type SeoFieldsOptions} from '../options'

export const robotsType = defineType({
  name: 'robots',
  title: 'Robots Settings',
  type: 'object',
  description:
    'Select how search engines should index, follow links, translate content, and index images on this page.',
  fields: [
    defineField({
      name: 'noIndex',
      title: 'No Index',
      type: 'boolean',
      initialValue: false,
      description: 'Prevent search engines from indexing this page. It will not appear in results.',
    }),
    defineField({
      name: 'noFollow',
      title: 'No Follow',
      type: 'boolean',
      initialValue: false,
      description: 'Prevent search engines from following links on this page.',
    }),
    defineField({
      name: 'noTranslate',
      title: 'No Translate',
      type: 'boolean',
      initialValue: false,
      description: 'Prevent search engines from offering a translated version of this page.',
    }),
    defineField({
      name: 'noImageIndex',
      title: 'No Image Index',
      type: 'boolean',
      initialValue: false,
      description: 'Prevent images on this page from appearing in image search.',
    }),
  ],
})

export const metaAttributeType = defineType({
  name: 'metaAttribute',
  title: 'Meta Attribute',
  type: 'object',
  fields: [
    defineField({name: 'key', title: 'Attribute Name', type: 'string'}),
    defineField({
      name: 'type',
      title: 'Attribute Value Type',
      type: 'string',
      options: {
        list: [
          {title: 'String', value: 'string'},
          {title: 'Image', value: 'image'},
        ],
      },
      initialValue: 'string',
    }),
    defineField({
      name: 'value',
      title: 'Attribute Value',
      type: 'string',
      hidden: ({parent}) => parent?.type === 'image',
    }),
    defineField({
      name: 'image',
      title: 'Attribute Image Value',
      type: 'image',
      hidden: ({parent}) => parent?.type === 'string',
    }),
  ],
  preview: {
    select: {key: 'key', value: 'value', image: 'image'},
    prepare({key, value, image}) {
      return {
        title: key || 'No attribute name',
        subtitle: value ? `Value: ${value}` : image ? 'Value: [Image]' : 'No value',
        media: image,
      }
    },
  },
})

/** Kept for datasets that used the upstream `metaTag` object. */
export const metaTagType = defineType({
  name: 'metaTag',
  title: 'Meta Tag',
  type: 'object',
  fields: [
    defineField({
      name: 'metaAttributes',
      title: 'Meta Attributes',
      type: 'array',
      of: [{type: 'metaAttribute'}],
    }),
  ],
})

export const hreflangEntryType = defineType({
  name: 'hreflangEntry',
  title: 'Hreflang Entry',
  type: 'object',
  fields: [
    defineField({
      name: 'locale',
      title: 'Language / Region',
      type: 'string',
      description: 'BCP 47 tag — e.g. en, fr-FR, x-default',
      validation: (Rule) =>
        Rule.required().custom((value?: string) => {
          if (!value) return 'Required'
          if (!/^(x-default|[a-z]{2,3}(-[A-Z]{2,3})?)$/.test(value)) {
            return 'Must be a valid BCP 47 tag (e.g. en, fr-FR, x-default)'
          }
          return true
        }),
    }),
    defineField({
      name: 'url',
      title: 'URL',
      type: 'url',
      validation: (Rule) => Rule.required().uri({scheme: ['http', 'https']}),
    }),
  ],
  preview: {select: {title: 'locale', subtitle: 'url'}},
})

const imageTypeField = (name: string) =>
  defineField({
    name: 'imageType',
    title: 'Image Type',
    type: 'string',
    options: {
      list: [
        {title: 'Upload Image', value: 'upload'},
        {title: 'Image URL', value: 'url'},
      ],
      layout: 'radio',
      direction: 'horizontal',
    },
    initialValue: 'upload',
    description: `Upload an image or link to one for ${name}.`,
  })

const uploadImageField = (title: string, description: string) =>
  defineField({
    name: 'image',
    title,
    type: 'image',
    description,
    options: {hotspot: true},
    fields: [
      defineField({
        name: 'alt',
        title: 'Image Alt Text',
        type: 'string',
        description: 'A description of the image for accessibility purposes.',
      }),
    ],
    hidden: ({parent}) => parent?.imageType === 'url',
  })

const imageUrlField = (title: string) =>
  defineField({
    name: 'imageUrl',
    title,
    type: 'url',
    description: 'Full URL of the image. It must be publicly reachable.',
    hidden: ({parent}) => parent?.imageType !== 'url',
  })

export const openGraphType = defineType({
  name: 'openGraph',
  title: 'Open Graph Settings',
  type: 'object',
  description: 'Overrides for Facebook, LinkedIn, WhatsApp etc. Leave blank to use the meta fields.',
  fields: [
    defineField({
      name: 'url',
      title: 'Open Graph URL',
      type: 'url',
      description: 'Canonical URL for social shares, including https://.',
    }),
    defineField({name: 'title', title: 'Open Graph Title', type: 'string'}),
    defineField({name: 'description', title: 'Open Graph Description', type: 'text', rows: 3}),
    defineField({
      name: 'siteName',
      title: 'Open Graph Site Name',
      type: 'string',
      description: 'The name of your website. This is often the site title.',
    }),
    defineField({
      name: 'type',
      title: 'Open Graph Type',
      type: 'string',
      options: {
        list: [
          {title: 'Website', value: 'website'},
          {title: 'Article', value: 'article'},
          {title: 'Profile', value: 'profile'},
          {title: 'Book', value: 'book'},
          {title: 'Music', value: 'music'},
          {title: 'Video', value: 'video'},
          {title: 'Product', value: 'product'},
        ],
      },
      initialValue: 'website',
    }),
    imageTypeField('Open Graph'),
    uploadImageField(
      'Open Graph Image',
      'Recommended 1200×630px (minimum 600×315px), under 5MB, aspect ratio 1.91:1.',
    ),
    imageUrlField('Open Graph Image URL'),
  ],
})

export const twitterType = defineType({
  name: 'twitter',
  title: 'X (Formerly Twitter)',
  type: 'object',
  description: 'Overrides for X cards. Leave blank to use the meta / Open Graph fields.',
  fields: [
    defineField({
      name: 'card',
      title: 'X Card Type',
      type: 'string',
      options: {
        list: [
          {title: 'Summary', value: 'summary'},
          {title: 'Summary with Large Image', value: 'summary_large_image'},
          {title: 'App', value: 'app'},
          {title: 'Player', value: 'player'},
        ],
      },
      initialValue: 'summary_large_image',
    }),
    defineField({
      name: 'site',
      title: 'Site X Handle',
      type: 'string',
      description: 'The X handle of the website (e.g. @example)',
    }),
    defineField({
      name: 'creator',
      title: 'X Creator Handle',
      type: 'string',
      description: 'The X handle of the content creator (e.g. @creator)',
    }),
    defineField({name: 'title', title: 'X Title', type: 'string'}),
    defineField({name: 'description', title: 'X Description', type: 'text', rows: 3}),
    imageTypeField('X'),
    uploadImageField(
      'X Image',
      'At least 120×120px for "summary" and 280×150px for "summary_large_image".',
    ),
    imageUrlField('X Image URL'),
  ],
})

export function seoFieldsType(options: SeoFieldsOptions = {}): SchemaTypeDefinition {
  const aiEndpoint = resolveAiEndpoint(options)
  const shared = {
    apiVersion: options.apiVersion ?? DEFAULT_API_VERSION,
    titleSuffix: options.titleSuffix,
    titleSuffixQuery: options.titleSuffixQuery,
    aiEndpoint,
  }

  return defineType({
    name: 'seoFields',
    title: 'SEO Fields',
    type: 'object',
    fields: [
      defineField({name: 'robots', title: 'Robots Settings', type: 'robots'}),
      defineField({
        name: 'preview',
        title: 'Search Preview',
        type: 'string',
        readOnly: true,
        initialValue: '',
        components: {input: SerpPreviewInput},
        options: {...shared, baseUrl: options.baseUrl} as Record<string, unknown>,
      }),
      defineField({
        name: 'title',
        title: 'Meta Title',
        type: 'string',
        description:
          'The clickable headline in search results. Do not add the brand name — the site appends it automatically.',
        components: {input: MetaTitleInput},
        options: shared as Record<string, unknown>,
      }),
      defineField({
        name: 'description',
        title: 'Meta Description',
        type: 'text',
        rows: 3,
        description: 'A concise summary shown under the title in search results.',
        components: {input: MetaDescriptionInput},
        options: shared as Record<string, unknown>,
      }),
      defineField({
        name: 'metaImage',
        title: 'Meta Image',
        type: 'image',
        description:
          'Default share image for this page (1200×630px). Used unless Open Graph / X images are set below.',
        options: {hotspot: true},
      }),
      defineField({
        name: 'focusKeyword',
        title: 'Focus Keyword',
        type: 'string',
        description:
          'The primary phrase you want this page to rank for. Checked against the title and description.',
      }),
      defineField({
        name: 'keywords',
        title: 'Keywords',
        type: 'array',
        of: [{type: 'string'}],
        options: {layout: 'tags'},
        description: 'Secondary phrases for this page.',
      }),
      defineField({
        name: 'canonicalUrl',
        title: 'Canonical URL',
        type: 'url',
        description:
          'Only set when this page duplicates another. The preferred version of the page.',
      }),
      defineField({
        name: 'metaAttributes',
        title: 'Additional Meta Attributes',
        type: 'array',
        of: [{type: 'metaAttribute'}],
        description: 'Custom <meta> tags for the head of this page.',
      }),
      defineField({
        name: 'hreflangs',
        title: 'Hreflang Entries',
        type: 'array',
        of: [{type: 'hreflangEntry'}],
        description: 'Alternate language/region versions. Include x-default for the fallback URL.',
      }),
      defineField({name: 'openGraph', title: 'Open Graph', type: 'openGraph'}),
      defineField({name: 'twitter', title: 'X (Twitter)', type: 'twitter'}),
    ],
  })
}

export function seoSchemaTypes(options: SeoFieldsOptions = {}): SchemaTypeDefinition[] {
  return [
    seoFieldsType(options),
    robotsType,
    openGraphType,
    twitterType,
    metaAttributeType,
    metaTagType,
    hreflangEntryType,
  ]
}
