import type {CustomValidator, Rule} from 'sanity'

import type {SeoFieldsValue} from '../shared/types'

/**
 * The "never blank" rule: a page cannot be published without a meta title,
 * description and share image. Use it on the `seo` field of every
 * page-level document type:
 *
 *   defineField({name: 'seo', type: 'seoFields', validation: requiredSeo})
 */
export const requiredSeoCheck: CustomValidator<SeoFieldsValue | undefined> = (value) => {
  const missing: string[] = []
  if (!value?.title?.trim()) missing.push('title')
  if (!value?.description?.trim()) missing.push('description')
  const hasShareImage =
    Boolean(value?.metaImage?.asset) ||
    (value?.openGraph?.imageType === 'url'
      ? Boolean(value?.openGraph?.imageUrl)
      : Boolean(value?.openGraph?.image?.asset))
  if (!hasShareImage) missing.push('meta image')
  return missing.length ? `Missing required SEO field(s): ${missing.join(', ')}.` : true
}

export const requiredSeo = (rule: Rule) =>
  rule.required().custom(requiredSeoCheck as CustomValidator<unknown>)
