export function SeoHealthIcon() {
  return (
    <svg
      width="1em"
      height="1em"
      viewBox="0 0 25 25"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M4 20 V6" />
      <path d="M4 20 H21" />
      <path d="M7 15 L11 10 L14 13 L19 7" />
      <path d="M16 7 H19 V10" />
    </svg>
  )
}
