export interface SeoFieldsOptions {
  /**
   * Site origin used by the SERP preview when a document has no canonical
   * URL, e.g. `https://www.example.com`. Defaults to the Studio's origin.
   */
  baseUrl?: string
  /**
   * Brand suffix the root layout appends (`%s | Brand`). Shown greyed in the
   * SERP preview and counted against the title length. A GROQ query
   * (`titleSuffixQuery`) wins over a static string.
   */
  titleSuffix?: string
  titleSuffixQuery?: string
  /**
   * Where the "Draft with AI" buttons post. Defaults to `/api/seo-ai` on the
   * Studio's origin (the Next.js route created with `createSeoAiHandler`).
   * Pass `false` to hide the buttons (e.g. a standalone Vite Studio).
   */
  ai?: {endpoint?: string} | false
  /** Register the "SEO Health" tool in the navbar. Default true. */
  healthTool?: boolean
  /** Document types the health tool scans. Default: every type with an `seo` field. */
  healthDocumentTypes?: string[]
  /** API version for the plugin's own client. */
  apiVersion?: string
}

export const DEFAULT_AI_ENDPOINT = '/api/seo-ai'
export const DEFAULT_API_VERSION = '2025-01-01'

export function resolveAiEndpoint(options: SeoFieldsOptions): string | null {
  if (options.ai === false) return null
  return options.ai?.endpoint ?? DEFAULT_AI_ENDPOINT
}
