import {Badge, Box, Button, Card, Container, Flex, Heading, Spinner, Text, TextInput} from '@sanity/ui'
import type React from 'react'
import {useCallback, useEffect, useMemo, useState} from 'react'
import {useClient, useSchema} from 'sanity'
import {IntentLink} from 'sanity/router'

import {SEO_LIMITS, type SeoFieldsValue} from '../shared/types'
import {DEFAULT_API_VERSION, type SeoFieldsOptions} from './options'
import {bandFor, scoreSeo, type SeoHealthBand} from './score'

interface Row {
  _id: string
  _type: string
  title: string
  seo: SeoFieldsValue | null
  score: number
  band: SeoHealthBand
  issues: string[]
}

const BAND_TONE: Record<SeoHealthBand, 'positive' | 'caution' | 'critical' | 'default'> = {
  excellent: 'positive',
  good: 'positive',
  fair: 'caution',
  poor: 'critical',
  missing: 'critical',
}

/** Document types whose schema carries a top-level `seo` field. */
function useSeoDocumentTypes(explicit?: string[]): string[] {
  const schema = useSchema()
  return useMemo(() => {
    if (explicit?.length) return explicit
    return schema
      .getTypeNames()
      .filter((name) => {
        const t = schema.get(name) as {type?: {name?: string}; fields?: {name: string}[]} | undefined
        return t?.type?.name === 'document' && t.fields?.some((f) => f.name === 'seo')
      })
      .sort()
  }, [schema, explicit])
}

export function SeoHealthTool({options}: {options: SeoFieldsOptions}) {
  const client = useClient({apiVersion: options.apiVersion ?? DEFAULT_API_VERSION})
  const types = useSeoDocumentTypes(options.healthDocumentTypes)
  const [rows, setRows] = useState<Row[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [filter, setFilter] = useState('')
  const [expanded, setExpanded] = useState<Set<string>>(new Set())
  const toggle = (id: string) =>
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })

  const load = useCallback(() => {
    if (!types.length) {
      setRows([])
      return
    }
    setRows(null)
    setError(null)
    client
      .fetch<Array<{_id: string; _type: string; title: string; seo: SeoFieldsValue | null}>>(
        `*[_type in $types && !(_id in path("drafts.**"))]{
          _id, _type,
          "title": coalesce(title, name, heading, seo.title, _id),
          seo{
            ...,
            metaImage{..., asset->{_id, url}},
            openGraph{..., image{..., asset->{_id, url}}}
          }
        } | order(_type asc, title asc)`,
        {types},
      )
      .then((docs) =>
        setRows(
          docs.map((d) => {
            const r = scoreSeo(d.seo)
            return {...d, ...r}
          }),
        ),
      )
      .catch((e) => setError(e instanceof Error ? e.message : String(e)))
  }, [client, types])

  useEffect(load, [load])

  const visible = useMemo(() => {
    if (!rows) return []
    const q = filter.trim().toLowerCase()
    const list = q
      ? rows.filter((r) => r.title.toLowerCase().includes(q) || r._type.toLowerCase().includes(q))
      : rows
    return [...list].sort((a, b) => a.score - b.score)
  }, [rows, filter])

  const average = rows?.length
    ? Math.round(rows.reduce((s, r) => s + r.score, 0) / rows.length)
    : 0

  return (
    <Box padding={4}>
      <Container width={3}>
        <Flex direction="column" gap={4}>
          <Flex align="center" justify="space-between" gap={3} wrap="wrap">
            <Flex direction="column" gap={2}>
              <Heading as="h1" size={2}>
                SEO Health
              </Heading>
              <Text size={1} muted>
                Every published page scored 0–100 on its meta title, description, share image and
                focus keyword. Lowest first — fix from the top.
              </Text>
            </Flex>
            <Flex align="center" gap={3}>
              {rows && rows.length > 0 && (
                <Badge tone={BAND_TONE[bandFor(average)]} fontSize={1} padding={2}>
                  Site average {average}
                </Badge>
              )}
              <Button text="Refresh" mode="ghost" onClick={load} />
            </Flex>
          </Flex>

          <TextInput
            placeholder="Filter by page title or type…"
            value={filter}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFilter(e.currentTarget.value)}
          />

          {error && (
            <Card tone="critical" padding={3} radius={2}>
              <Text size={1}>{error}</Text>
            </Card>
          )}
          {!rows && !error && (
            <Flex justify="center" padding={5}>
              <Spinner />
            </Flex>
          )}
          {rows && types.length === 0 && (
            <Card tone="caution" padding={3} radius={2}>
              <Text size={1}>
                No document type has an <code>seo</code> field yet. Add{' '}
                <code>{`defineField({name: 'seo', type: 'seoFields'})`}</code> to your page schemas.
              </Text>
            </Card>
          )}

          <Flex direction="column" gap={2}>
            {visible.map((r) => (
              <Card key={r._id} padding={3} radius={2} border>
                <Flex align="flex-start" gap={3}>
                  <Badge tone={BAND_TONE[r.band]} fontSize={1} padding={2} style={{minWidth: 44, textAlign: 'center'}}>
                    {r.score}
                  </Badge>
                  <Flex direction="column" gap={2} flex={1}>
                    <Flex align="center" gap={2} wrap="wrap">
                      <Text weight="medium">
                        <IntentLink
                          intent="edit"
                          params={{id: r._id, type: r._type}}
                          style={{color: 'inherit', textDecoration: 'none'}}
                        >
                          {r.title}
                        </IntentLink>
                      </Text>
                      <Badge fontSize={0}>
                        {r._type}
                      </Badge>
                    </Flex>
                    {r.issues.length > 0 && (
                      <Text size={1} muted>
                        {r.issues.join(' · ')}
                      </Text>
                    )}
                    {expanded.has(r._id) && <SeoFieldsSummary seo={r.seo} />}
                  </Flex>
                  <Button
                    mode="bleed"
                    fontSize={1}
                    padding={2}
                    text={expanded.has(r._id) ? 'Hide fields' : 'Show fields'}
                    onClick={() => toggle(r._id)}
                  />
                </Flex>
              </Card>
            ))}
          </Flex>
        </Flex>
      </Container>
    </Box>
  )
}

/** The stored SEO fields for one page, so an editor can see what the score is based on. */
function SeoFieldsSummary({seo}: {seo: SeoFieldsValue | null}) {
  if (!seo) return null
  const shareImage =
    seo.metaImage?.asset?.url ??
    (seo.openGraph?.imageType === 'url' ? seo.openGraph.imageUrl : seo.openGraph?.image?.asset?.url)
  const robots = [seo.robots?.noIndex && 'noindex', seo.robots?.noFollow && 'nofollow'].filter(Boolean)
  return (
    <Card padding={3} radius={2} tone="transparent" border>
      <Flex gap={4} wrap="wrap">
        <Flex direction="column" gap={3} flex={1} style={{minWidth: 240}}>
          <Field label="Meta title" value={seo.title} count={SEO_LIMITS.title} />
          <Field label="Meta description" value={seo.description} count={SEO_LIMITS.description} />
          <Field label="Focus keyword" value={seo.focusKeyword} />
          <Field label="Canonical URL" value={seo.canonicalUrl} />
          <Field label="Open Graph title" value={seo.openGraph?.title} />
          <Field label="Open Graph description" value={seo.openGraph?.description} />
          {robots.length > 0 && <Field label="Robots" value={robots.join(', ')} />}
        </Flex>
        <Flex direction="column" gap={2}>
          <Text size={0} muted weight="medium">
            Share image
          </Text>
          {shareImage ? (
            <img
              src={shareImage.includes('cdn.sanity.io') ? `${shareImage}?w=240&h=126&fit=crop&auto=format` : shareImage}
              alt=""
              width={240}
              height={126}
              style={{objectFit: 'cover', borderRadius: 4, display: 'block'}}
            />
          ) : (
            <Text size={1} muted>
              — not set —
            </Text>
          )}
        </Flex>
      </Flex>
    </Card>
  )
}

function Field({label, value, count}: {label: string; value?: string; count?: {min: number; max: number}}) {
  const v = value?.trim() ?? ''
  const tooShort = count && v.length > 0 && v.length < count.min
  const tooLong = count && v.length > count.max
  return (
    <Flex direction="column" gap={1}>
      <Text size={0} muted weight="medium">
        {label}
        {count && v && (
          <span style={{opacity: 0.7, fontWeight: 400}}>
            {' '}
            · {v.length}/{count.max}
            {tooShort ? ' (short)' : tooLong ? ' (long)' : ''}
          </span>
        )}
      </Text>
      <Text size={1} muted={!v}>
        {v || '— not set —'}
      </Text>
    </Flex>
  )
}
