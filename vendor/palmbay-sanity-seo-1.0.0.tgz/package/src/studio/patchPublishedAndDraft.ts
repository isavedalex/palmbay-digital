import type {SanityClient} from 'sanity'

export interface PatchOps {
  set?: Record<string, unknown>
  setIfMissing?: Record<string, unknown>
  unset?: string[]
}

/**
 * Apply the same patch to a published document and, if the editor has an
 * open draft, to the draft as well — otherwise their next publish would
 * silently undo a change made from a tool pane.
 */
export async function patchPublishedAndDraft(
  client: SanityClient,
  docId: string,
  ops: PatchOps,
): Promise<void> {
  const ids = await client.fetch<string[]>(`*[_id in $ids]._id`, {ids: [docId, `drafts.${docId}`]})
  const tx = client.transaction()
  for (const id of ids) tx.patch(id, ops)
  await tx.commit({autoGenerateArrayKeys: true})
}
