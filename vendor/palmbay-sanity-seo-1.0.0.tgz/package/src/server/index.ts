/**
 * `@palmbay/sanity-seo/server` — Node only. Creates the POST handler the
 * Studio's "Draft with AI" and "Generate alt text" buttons call.
 *
 *   // app/api/seo-ai/route.ts
 *   import {createSeoAiHandler} from '@palmbay/sanity-seo/server'
 *   export const POST = createSeoAiHandler()
 *
 * Security model: the route is same-origin only (Origin header must match
 * the request host), rate-limited per IP, and will only describe images
 * hosted on this project's Sanity CDN. The Anthropic key never reaches the
 * browser. Anyone who can reach the Studio can spend a few pence describing
 * the project's own images — acceptable for an editor-only tool.
 */
import Anthropic from '@anthropic-ai/sdk'

import {SEO_LIMITS, type KeywordSuggestion, type SeoAiRequest} from '../shared/types'
import {describeKeywordContext, getKeywordContext, type KeywordContext} from './keywordContext'

export interface SeoAiHandlerOptions {
  /** Defaults to `process.env.ANTHROPIC_API_KEY`. */
  apiKey?: string
  /** Vision model for alt text. */
  altModel?: string
  /** Model for title/description drafts. */
  textModel?: string
  /**
   * Sanity project ID; only `cdn.sanity.io/images/<projectId>/...` URLs are
   * described. Defaults to `process.env.NEXT_PUBLIC_SANITY_PROJECT_ID`.
   */
  projectId?: string
  /** Extra image hosts to allow, e.g. a custom CDN hostname. */
  allowedImageHosts?: string[]
  /** Requests per IP per minute. Default 20. */
  rateLimitPerMinute?: number
  /** Skip the same-origin check (e.g. a standalone Studio on another host). */
  allowedOrigins?: string[]
  /** Language / locale hint for the copy, e.g. 'British English'. */
  language?: string
  /**
   * OpenSEO share link (the same URL the `openSeo()` tab embeds). When set,
   * the title/description/keyword tasks are steered by what the site already
   * ranks for and the queries Search Console attributes to the page.
   * Defaults to `process.env.OPENSEO_EMBED_URL` or
   * `process.env.NEXT_PUBLIC_OPENSEO_EMBED_URL`.
   */
  openSeoEmbedUrl?: string
}

const hits = new Map<string, {count: number; reset: number}>()
function rateLimited(key: string, perMinute: number): boolean {
  const now = Date.now()
  const slot = hits.get(key)
  if (!slot || slot.reset < now) {
    hits.set(key, {count: 1, reset: now + 60_000})
    return false
  }
  slot.count++
  return slot.count > perMinute
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {status, headers: {'content-type': 'application/json'}})

export function createSeoAiHandler(options: SeoAiHandlerOptions = {}) {
  const apiKey = options.apiKey ?? process.env.ANTHROPIC_API_KEY
  const projectId = options.projectId ?? process.env.NEXT_PUBLIC_SANITY_PROJECT_ID
  const altModel = options.altModel ?? 'claude-haiku-4-5'
  const textModel = options.textModel ?? 'claude-sonnet-5'
  const perMinute = options.rateLimitPerMinute ?? 20
  const language = options.language ?? 'British English'
  const embedUrl =
    options.openSeoEmbedUrl ??
    process.env.OPENSEO_EMBED_URL ??
    process.env.NEXT_PUBLIC_OPENSEO_EMBED_URL
  const client = apiKey ? new Anthropic({apiKey}) : null

  const imageAllowed = (raw: string): boolean => {
    let u: URL
    try {
      u = new URL(raw)
    } catch {
      return false
    }
    if (u.protocol !== 'https:') return false
    if (options.allowedImageHosts?.includes(u.hostname)) return true
    if (u.hostname !== 'cdn.sanity.io') return false
    return projectId ? u.pathname.startsWith(`/images/${projectId}/`) : true
  }

  return async function POST(req: Request): Promise<Response> {
    if (!client) return json({error: 'ANTHROPIC_API_KEY is not set on the server.'}, 500)

    // Same-origin only. Browsers always send Origin on cross-site POSTs.
    const origin = req.headers.get('origin')
    const host = req.headers.get('x-forwarded-host') ?? req.headers.get('host')
    if (origin) {
      const originHost = (() => {
        try {
          return new URL(origin).host
        } catch {
          return ''
        }
      })()
      const ok = originHost === host || options.allowedOrigins?.includes(origin)
      if (!ok) return json({error: 'Forbidden'}, 403)
    }

    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'local'
    if (rateLimited(ip, perMinute)) return json({error: 'Too many requests — wait a minute.'}, 429)

    let body: SeoAiRequest
    try {
      body = (await req.json()) as SeoAiRequest
    } catch {
      return json({error: 'Invalid JSON'}, 400)
    }

    try {
      if (body.task === 'alt') {
        if (!body.imageUrl || !imageAllowed(body.imageUrl)) {
          return json({error: 'imageUrl must be an image on this project’s Sanity CDN.'}, 400)
        }
        const res = await client.messages.create({
          model: altModel,
          max_tokens: 200,
          system: `You write alt text for a small business website in ${language}. Reply with the alt text only: one sentence, at most ${SEO_LIMITS.alt.max} characters, no quotes, no "image of" or "picture of", no trailing full stop. Describe what is actually visible and relevant to a visitor; name the business or place only if the page context makes it certain.`,
          messages: [
            {
              role: 'user',
              content: [
                {type: 'image', source: {type: 'url', url: body.imageUrl}},
                {
                  type: 'text',
                  text: body.context
                    ? `Page context: ${body.context.slice(0, 600)}\n\nWrite the alt text.`
                    : 'Write the alt text.',
                },
              ],
            },
          ],
        })
        return json({result: firstText(res).slice(0, SEO_LIMITS.alt.max)})
      }

      if (body.task === 'keyword') {
        if (!body.text?.trim()) return json({error: 'text is required'}, 400)
        const ctx = await getKeywordContext(embedUrl, body.pagePath)
        const res = await client.messages.create({
          model: textModel,
          max_tokens: 1000,
          thinking: {type: 'adaptive'},
          output_config: {
            effort: 'low',
            format: {
              type: 'json_schema',
              schema: {
                type: 'object',
                properties: {
                  suggestions: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        keyword: {type: 'string'},
                        reason: {type: 'string'},
                      },
                      required: ['keyword', 'reason'],
                      additionalProperties: false,
                    },
                  },
                },
                required: ['suggestions'],
                additionalProperties: false,
              },
            },
          },
          system: `You choose the focus keyword for one page of a small business website, in ${language}. Return three to five candidates, best first, each with a one-line reason a non-expert would understand.

Prefer, in this order: a term this page already ranks for between positions 4 and 20 (closest to page one wins), a query Search Console attributes to this page with impressions but few clicks, then a keyword with real demand that matches what the page is actually about. Never suggest a term the page's content does not support.

When you pick a term from the list below, copy it character for character — "post natal doula" and "postnatal doula" are different terms and only an exact copy can be matched to its measured figures.

The reason must contain no numbers at all: no positions, no impressions, no search volumes. The interface prints the measured figures next to each suggestion, taken from the data below rather than from you. Say only why the term fits this page and why it is worth targeting.`,
          messages: [
            {
              role: 'user',
              content: `${keywordBlock(ctx)}Page content:\n\n${body.text.slice(0, 6000)}`,
            },
          ],
        })
        const parsed = JSON.parse(firstText(res) || '{}') as {suggestions?: KeywordSuggestion[]}
        return json({suggestions: withMetrics(parsed.suggestions ?? [], ctx).slice(0, 5)})
      }

      if (
        body.task === 'title' ||
        body.task === 'description' ||
        body.task === 'ogTitle' ||
        body.task === 'ogDescription'
      ) {
        if (!body.text?.trim()) return json({error: 'text is required'}, 400)
        const isOg = body.task === 'ogTitle' || body.task === 'ogDescription'
        const isTitle = body.task === 'title' || body.task === 'ogTitle'
        const limits = isTitle ? SEO_LIMITS.title : SEO_LIMITS.description
        const brandLen = isTitle && !isOg && body.siteName ? body.siteName.length + 3 : 0
        const max = isTitle ? limits.max - brandLen : limits.max
        const ctx = isOg ? null : await getKeywordContext(embedUrl, body.pagePath)

        // Open Graph copy is read in a social feed, not a search result, so
        // it is written for the scroll rather than for keywords.
        const system = isOg
          ? isTitle
            ? `You write Open Graph titles — the headline shown when a page of a small business website is shared on social media or in a message, in ${language}. Reply with the title only, no quotes. At most ${max} characters. Write for someone scrolling, not for a search engine: concrete and human. ${body.metaTitle ? `The search-result title is "${body.metaTitle}" — complement it, don't repeat it word for word.` : ''}`
            : `You write Open Graph descriptions — the line under the headline when a page is shared on social media, in ${language}. Reply with the description only, no quotes. One sentence, at most ${max} characters, no exclamation marks. Say why someone would tap through. ${body.metaDescription ? `The meta description is "${body.metaDescription}" — complement it, don't repeat it word for word.` : ''}`
          : isTitle
            ? `You write SEO meta titles for a small business website in ${language}. Reply with the title only, no quotes. Between ${Math.max(20, limits.min - brandLen)} and ${max} characters. Lead with what the page is about and where, in plain words a customer would search. ${body.siteName ? `Do NOT include "${body.siteName}" — the site appends it automatically.` : ''} ${body.focusKeyword ? `Include the phrase "${body.focusKeyword}" naturally, ideally near the start.` : ''} ${ctx?.candidates.length ? 'Work in the highest-value keyword below that the page genuinely supports — a term already ranking just off page one is worth more than a new one.' : ''}`
            : `You write SEO meta descriptions for a small business website in ${language}. Reply with the description only, no quotes. Between ${limits.min} and ${max} characters, one or two sentences. Say what the visitor gets on this page and why this business, in a warm, specific, non-salesy voice. No exclamation marks. ${body.focusKeyword ? `Include the phrase "${body.focusKeyword}" once, naturally.` : ''} ${ctx?.candidates.length ? 'Where it reads naturally, echo the wording of a query below that this page already earns impressions for.' : ''}`

        const res = await client.messages.create({
          model: textModel,
          max_tokens: 300,
          thinking: {type: 'adaptive'},
          output_config: {effort: 'low'},
          system,
          messages: [
            {role: 'user', content: `${keywordBlock(ctx)}Page content:\n\n${body.text.slice(0, 6000)}`},
          ],
        })
        return json({result: firstText(res).replace(/^["“]|["”]$/g, '').trim()})
      }

      return json({error: 'Unknown task'}, 400)
    } catch (e) {
      if (e instanceof Anthropic.RateLimitError) return json({error: 'AI provider is busy — try again shortly.'}, 503)
      if (e instanceof Anthropic.APIError) return json({error: `AI error: ${e.message}`}, 502)
      return json({error: e instanceof Error ? e.message : 'Unexpected error'}, 500)
    }
  }
}

function keywordBlock(ctx: KeywordContext | null): string {
  const described = describeKeywordContext(ctx)
  return described ? `${described}\n\n` : ''
}

/**
 * Attach the numbers we already hold to each suggestion, so the Studio can
 * show "pos 7 · 240 impressions" without the model restating (or inventing)
 * them.
 */
function withMetrics(
  suggestions: KeywordSuggestion[],
  ctx: KeywordContext | null,
): KeywordSuggestion[] {
  const byKeyword = new Map(
    (ctx?.candidates ?? []).map((c) => [c.keyword.trim().toLowerCase(), c]),
  )
  return suggestions.map((s) => {
    const match = byKeyword.get(s.keyword.trim().toLowerCase())
    return match
      ? {
          ...s,
          position: match.position,
          impressions: match.impressions,
          searchVolume: match.searchVolume,
        }
      : s
  })
}

function firstText(res: Anthropic.Message): string {
  for (const block of res.content) if (block.type === 'text') return block.text.trim()
  return ''
}
