/**
 * Pulls the OpenSEO share-link snapshot (`/embed/<token>?format=json`) and
 * distils it into the keyword picture for one page: what it already ranks
 * for, what it earns impressions for without ranking well, and saved ideas
 * nobody is tracking yet. The AI prompts use this to steer titles and
 * descriptions toward terms with real demand rather than paraphrasing copy.
 */

interface RankKeyword {
  keyword: string
  position: number | null
  previousPosition: number | null
  rankingUrl: string | null
  searchVolume: number | null
}
interface PageQuery {
  page: string
  query: string
  clicks: number
  impressions: number
  ctr: number
  position: number
}
interface KeywordIdea {
  keyword: string
  searchVolume: number | null
  keywordDifficulty: number | null
  intent: string | null
  tracked: boolean
}
interface Snapshot {
  project?: {domain?: string}
  rankSummary?: {keywords: RankKeyword[]} | null
  keywordIdeas?: {keywords: KeywordIdea[]} | null
  searchConsole?: {
    queries: Array<Omit<PageQuery, 'page'>>
    pageQueries?: PageQuery[]
  } | null
}

export interface KeywordCandidate {
  keyword: string
  /** Where the term comes from — tracked rank, Search Console, or a saved idea. */
  source: 'rank' | 'search-console' | 'idea'
  position: number | null
  impressions: number | null
  clicks: number | null
  searchVolume: number | null
  /** True when the signal is attributed to this page rather than the whole site. */
  thisPage: boolean
}

export interface KeywordContext {
  domain: string | null
  candidates: KeywordCandidate[]
}

const CACHE_TTL_MS = 10 * 60_000
let cache: {url: string; at: number; data: Snapshot} | null = null

async function loadSnapshot(embedUrl: string): Promise<Snapshot | null> {
  if (cache && cache.url === embedUrl && Date.now() - cache.at < CACHE_TTL_MS) return cache.data
  const url = new URL(embedUrl)
  url.searchParams.set('format', 'json')
  const res = await fetch(url, {headers: {accept: 'application/json'}})
  if (!res.ok) return null
  const data = (await res.json()) as Snapshot
  cache = {url: embedUrl, at: Date.now(), data}
  return data
}

function pathOf(raw: string | null | undefined): string | null {
  if (!raw) return null
  try {
    const p = new URL(raw).pathname.replace(/\/+$/, '')
    return p || '/'
  } catch {
    return null
  }
}

const norm = (s: string) => s.trim().toLowerCase()

/**
 * Build the candidate list for one page. `pagePath` is the site path the
 * document renders at (`/`, `/about`); when unknown, everything is treated
 * as site-wide.
 */
export async function getKeywordContext(
  embedUrl: string | undefined,
  pagePath: string | undefined,
): Promise<KeywordContext | null> {
  if (!embedUrl) return null
  let snap: Snapshot | null
  try {
    snap = await loadSnapshot(embedUrl)
  } catch {
    return null
  }
  if (!snap) return null

  const page = pagePath ? pagePath.replace(/\/+$/, '') || '/' : null
  const byKeyword = new Map<string, KeywordCandidate>()
  const add = (c: KeywordCandidate) => {
    const key = norm(c.keyword)
    if (!key) return
    const prev = byKeyword.get(key)
    // Page-attributed signals beat site-wide ones; otherwise keep the first.
    if (!prev || (c.thisPage && !prev.thisPage)) byKeyword.set(key, {...prev, ...c})
    else if (prev) {
      prev.searchVolume ??= c.searchVolume
      prev.impressions ??= c.impressions
      prev.position ??= c.position
    }
  }

  for (const k of snap.rankSummary?.keywords ?? []) {
    add({
      keyword: k.keyword,
      source: 'rank',
      position: k.position,
      impressions: null,
      clicks: null,
      searchVolume: k.searchVolume,
      thisPage: page !== null && pathOf(k.rankingUrl) === page,
    })
  }
  const pageQueries = snap.searchConsole?.pageQueries ?? []
  for (const q of pageQueries) {
    const mine = page !== null && pathOf(q.page) === page
    if (!mine && page !== null && pageQueries.length > 0) continue
    add({
      keyword: q.query,
      source: 'search-console',
      position: q.position,
      impressions: q.impressions,
      clicks: q.clicks,
      searchVolume: null,
      thisPage: mine,
    })
  }
  if (page === null || pageQueries.length === 0) {
    for (const q of snap.searchConsole?.queries ?? []) {
      add({
        keyword: q.query,
        source: 'search-console',
        position: q.position,
        impressions: q.impressions,
        clicks: q.clicks,
        searchVolume: null,
        thisPage: false,
      })
    }
  }
  for (const k of snap.keywordIdeas?.keywords ?? []) {
    if (k.tracked) continue
    add({
      keyword: k.keyword,
      source: 'idea',
      position: null,
      impressions: null,
      clicks: null,
      searchVolume: k.searchVolume,
      thisPage: false,
    })
  }

  // This page first, then striking-distance terms (positions 4–20 with
  // demand), then everything else by demand.
  const demand = (c: KeywordCandidate) => (c.impressions ?? 0) + (c.searchVolume ?? 0)
  const striking = (c: KeywordCandidate) => c.position !== null && c.position >= 4 && c.position <= 20
  const candidates = [...byKeyword.values()]
    .sort((a, b) => {
      if (a.thisPage !== b.thisPage) return a.thisPage ? -1 : 1
      if (striking(a) !== striking(b)) return striking(a) ? -1 : 1
      return demand(b) - demand(a)
    })
    .slice(0, 40)

  return {domain: snap.project?.domain ?? null, candidates}
}

/** Compact, prompt-ready rendering of the candidates. */
export function describeKeywordContext(ctx: KeywordContext | null): string {
  if (!ctx || ctx.candidates.length === 0) return ''
  const line = (c: KeywordCandidate) => {
    const bits: string[] = []
    if (c.position !== null) bits.push(`pos ${Math.round(c.position)}`)
    if (c.impressions !== null) bits.push(`${c.impressions} impr/28d`)
    if (c.clicks !== null && c.clicks > 0) bits.push(`${c.clicks} clicks`)
    if (c.searchVolume !== null) bits.push(`${c.searchVolume}/mo`)
    return `- "${c.keyword}" (${c.source}${bits.length ? '; ' + bits.join(', ') : ''})`
  }
  const mine = ctx.candidates.filter((c) => c.thisPage)
  const rest = ctx.candidates.filter((c) => !c.thisPage)
  const parts: string[] = []
  if (mine.length) parts.push(`Queries and rankings attributed to THIS page:\n${mine.map(line).join('\n')}`)
  if (rest.length) parts.push(`Site-wide keywords (tracked ranks, Search Console, saved ideas):\n${rest.map(line).join('\n')}`)
  return parts.join('\n\n')
}
