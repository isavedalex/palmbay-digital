/**
 * Palm Bay editor tours for `sanity-plugin-editor-onboarding` (MIT,
 * © Henrik Larsson). That plugin is an optional peer — it needs sanity ^6 —
 * so this module only produces data; the site registers the tool itself:
 *
 *   import {onboardingTool} from 'sanity-plugin-editor-onboarding'
 *   import {palmBayTours, palmBayFieldGuides} from '@palmbay/sanity-seo'
 *   plugins: [onboardingTool({tours: palmBayTours(), fieldGuides: palmBayFieldGuides()})]
 */
import type {FieldGuide, OnboardingTour} from 'sanity-plugin-editor-onboarding'
import {
  coreConcepts,
  targetNavbar,
  targetPublishButton,
  targetToolMenu,
} from 'sanity-plugin-editor-onboarding'

export interface PalmBayToursOptions {
  /** Brand name used in copy, e.g. "Cork & Capture". */
  siteName?: string
  /** Include the plugin's built-in drafts/publishing/media tours. Default true. */
  includeCoreConcepts?: boolean
  /** Whether the Rank Tracking tab is registered on this Studio. Default true. */
  rankTracking?: boolean
}

export function palmBayTours(options: PalmBayToursOptions = {}): OnboardingTour[] {
  const {siteName = 'your site', includeCoreConcepts = true, rankTracking = true} = options

  const welcome: OnboardingTour = {
    id: 'palmbay-welcome',
    title: 'Welcome to your CMS',
    description: 'A two-minute lap of where things are.',
    autoStart: 'first-login',
    steps: [
      {
        title: `This is where ${siteName} is edited`,
        content:
          'Everything on the live site comes from here. Nothing changes publicly until you press Publish, so it is safe to explore.',
      },
      {
        target: targetToolMenu(),
        title: 'The tabs',
        content: rankTracking
          ? 'Structure is your content. SEO Health scores every page. Alt Text finds images with no description. Rank Tracking shows where you appear on Google.'
          : 'Structure is your content. SEO Health scores every page. Alt Text finds images with no description.',
      },
      {
        target: targetNavbar(),
        title: 'Need help later?',
        content: 'The book icon in this bar brings these guides back at any time.',
      },
    ],
  }

  const editPage: OnboardingTour = {
    id: 'palmbay-edit-page',
    title: 'Edit and publish a page',
    description: 'Open a page, change something, and make it live.',
    unavailableMessage: 'Open a page from the Structure tab first, then start this guide.',
    steps: [
      {
        title: 'Open a page',
        content: 'In Structure, pick the page you want to change. Each page is one document.',
      },
      {
        title: 'Make your change',
        content:
          'Edit text straight in the fields. Your changes save as a draft automatically — you will see "Draft" at the top while you work.',
      },
      {
        target: targetPublishButton(),
        title: 'Publish',
        content:
          'Press Publish to put the change on the live site. It usually appears within a minute. If Publish is greyed out, a required field is empty — look for the red marker.',
      },
    ],
  }

  const seoTour: OnboardingTour = {
    id: 'palmbay-seo',
    title: 'Fill in the SEO tab',
    description: 'The three fields Google reads, and how to write them.',
    unavailableMessage: 'Open a page and scroll to its SEO section first.',
    steps: [
      {
        field: 'seo.title',
        title: 'Meta title',
        content: `The headline Google shows. 30–60 characters, lead with what the page is about. Leave out "${siteName === 'your site' ? 'the brand' : siteName}" — it is added automatically.`,
      },
      {
        field: 'seo.description',
        title: 'Meta description',
        content:
          'The two lines under the headline. 70–160 characters. Say what someone gets on this page and why you. "Draft with AI" writes a first version from the page copy.',
      },
      {
        field: 'seo.focusKeyword',
        title: 'Focus keyword',
        content:
          'The phrase you want this page found for, e.g. "wedding photographer Cork". Use it once in the title and once in the description.',
      },
      {
        field: 'seo.metaImage',
        title: 'Share image',
        content:
          'The picture shown when the page is shared on WhatsApp, Facebook or LinkedIn. Landscape, 1200×630 works best.',
      },
      {
        field: 'seo.preview',
        title: 'Check the preview',
        content:
          'This is exactly what the Google result will look like. If the title is cut off with "…", shorten it.',
      },
    ],
  }

  const altTextTour: OnboardingTour = {
    id: 'palmbay-alt-text',
    title: 'Describe your images',
    description: 'Why alt text matters and how to fill it in quickly.',
    steps: [
      {
        title: 'What alt text is',
        content:
          'A one-line description of an image. Screen readers read it aloud, and Google uses it to understand the picture. Every image should have one.',
      },
      {
        title: 'Generate it',
        content:
          'Under any image, "Generate alt text" writes a description for you. Read it, tweak it if needed, and publish. The Alt Text tab lists every image still missing one.',
      },
    ],
  }

  const tours = [welcome, editPage, seoTour, altTextTour]
  return includeCoreConcepts ? [...tours, ...coreConcepts()] : tours
}

/** Field-level help (book icon) for the SEO fields, on every document type. */
export function palmBayFieldGuides(): FieldGuide[] {
  return [
    {
      field: 'seo.canonicalUrl',
      title: 'Canonical URL',
      content:
        'Leave this empty unless this page is a copy of another page. It tells Google which one is the original.',
    },
    {
      field: 'seo.robots',
      title: 'Robots settings',
      content:
        'Turn on "No Index" only for pages you do not want on Google at all — thank-you pages, private offers. Everything else stays off.',
    },
    {
      field: 'seo.openGraph',
      title: 'Open Graph',
      content:
        'Optional overrides for how the page looks when shared on social media. Blank means the meta title, description and image are used.',
    },
    {
      field: 'seo.keywords',
      title: 'Keywords',
      content:
        'Secondary phrases this page should rank for. Google does not read these directly; they guide your writing and the SEO Health score.',
    },
  ]
}
