# @palmbay/sanity-seo

Palm Bay Digital's Sanity Studio SEO toolkit, in one package:

| Module | What it gives you |
| --- | --- |
| `seoFields()` | The `seoFields` object type (meta title/description with counters and duplicate check, share image, focus keyword, robots, canonical, hreflang, Open Graph, X), a live Google search preview, and an **SEO Health** tab that scores every page 0–100. |
| `openSeo()` | A **Rank Tracking** tab embedding a read-only [OpenSEO](https://openseo.so) share link. |
| **SEO Health** | Expand any page to edit its meta title, description, focus keyword, canonical and Open Graph copy in place, each with an AI button. |
| `altText()` + `altTextField()` | A "Generate alt text" button on any image, and an **Alt Text** tab that finds every image with no description and fills them in one transaction. |
| `@palmbay/sanity-seo/next` | `buildSeoMeta()` for `generateMetadata`, the matching `seoProjection` GROQ fragment, `isIndexable()` for sitemaps, and JSON-LD builders (`localBusinessJsonLd`, `articleJsonLd`, `faqPageJsonLd`, …) with a `<JsonLd/>` component. |
| `@palmbay/sanity-seo/server` | `createSeoAiHandler()` — the Next.js route the AI buttons call. Claude runs server-side; the key never reaches the browser. Give it an OpenSEO share link and the drafts are steered by what the site already ranks for. |
| `@palmbay/sanity-seo/onboarding` | `palmBayTours()` / `palmBayFieldGuides()` for [sanity-plugin-editor-onboarding](https://www.sanity.io/plugins/sanity-plugin-editor-onboarding) (Sanity 6 only). |

The `seoFields` schema is field-for-field compatible with `sanity-plugin-seofields` v1.x, so swapping the plugin needs no content migration. No licence keys anywhere.

## Install

```sh
npm install @palmbay/sanity-seo @anthropic-ai/sdk
# Only if you want the onboarding tours (Sanity 6 studios):
npm install sanity-plugin-editor-onboarding
```

`sanity-plugin-editor-onboarding` is deliberately **not** a peer dependency: it is Sanity 6 only, and npm resolves optional peers eagerly, so declaring it broke installs on every Sanity 4 and 5 studio. Import `@palmbay/sanity-seo/onboarding` only once you've installed it yourself.

Peers: `sanity ^4 || ^5 || ^6`, `react ^18 || ^19`. `@sanity/ui` is declared as `^3 || ^4` so it dedupes to whatever your Studio already ships.

## Studio

```ts
// sanity.config.ts
import {defineConfig} from 'sanity'
import {seoFields, openSeo, altText} from '@palmbay/sanity-seo'

export default defineConfig({
  // ...
  plugins: [
    seoFields({titleSuffix: 'Cork & Capture'}), // the " | Brand" your layout appends
    altText(),
    openSeo({embedUrl: process.env.NEXT_PUBLIC_OPENSEO_EMBED_URL}),
  ],
})
```

```ts
// every page-level document type
import {requiredSeo, altTextField} from '@palmbay/sanity-seo'

defineField({name: 'seo', type: 'seoFields', validation: requiredSeo})
defineField({name: 'image', type: 'image', fields: [altTextField()]})
```

`requiredSeo` blocks publishing until title, description and a share image are set.

Options for `seoFields()`: `titleSuffix` / `titleSuffixQuery`, `baseUrl` (for the preview URL), `ai: {endpoint}` or `ai: false`, `healthTool: false`, `healthDocumentTypes: [...]`.

### Standalone (Vite) studios

There is no Next.js route, so pass `ai: false` (or an absolute `ai.endpoint` on a host that runs the handler) and read the OpenSEO URL from `import.meta.env.VITE_…`.

## The AI route (Next.js App Router)

```ts
// app/api/seo-ai/route.ts
import {createSeoAiHandler} from '@palmbay/sanity-seo/server'
export const POST = createSeoAiHandler()
```

Set `ANTHROPIC_API_KEY` on the server (a **Sensitive** Vercel env var). The handler is same-origin only, rate-limited per IP, and will only describe images on this project's Sanity CDN (`NEXT_PUBLIC_SANITY_PROJECT_ID`). Options: `altModel` (default `claude-haiku-4-5`), `textModel` (default `claude-sonnet-5`), `language`, `allowedImageHosts`, `allowedOrigins`, `rateLimitPerMinute`, `openSeoEmbedUrl`.

### Keyword-aware drafts

Point the handler at the same OpenSEO share link the `openSeo()` tab embeds and the title, description and focus-keyword drafts stop guessing:

```ts
export const POST = createSeoAiHandler({
  openSeoEmbedUrl: process.env.OPENSEO_EMBED_URL, // or NEXT_PUBLIC_OPENSEO_EMBED_URL
})
```

The route reads `<share link>?format=json` server-side (cached 10 minutes) and hands Claude, for the page being edited: the tracked keywords whose ranking URL is this page, the Search Console queries attributed to this page over the last 28 days, and — as a fallback — the site's own tracked ranks, top queries and saved keyword ideas. Terms sitting in positions 4–20 are ranked first, because moving one of those onto page one is worth more than starting from nothing.

**Focus keyword** gets a **Suggest** button instead of a draft: three to five candidates, each with its measured position and impressions and a one-line reason, and one click fills the field. Open Graph copy deliberately skips the keyword context — it is read in a feed, not a search result.

This needs the page's slug to attribute queries; without one the suggestions fall back to site-wide. Requires OpenSEO Search Console to be connected — no share link, or no GSC, and the buttons quietly behave as before.

## The site

```ts
// app/about/page.tsx
import {buildSeoMeta, seoProjection} from '@palmbay/sanity-seo/next'

export async function generateMetadata() {
  const page = await client.fetch(`*[_type == "aboutPage"][0]{ title, ${seoProjection} }`)
  return buildSeoMeta({
    seo: page?.seo,
    baseUrl: process.env.NEXT_PUBLIC_SITE_URL!,
    path: '/about',
    defaults: {title: 'About', description: '…', image: `${SITE_URL}/og.png`, siteName: 'Brand'},
  })
}
```

`buildSeoMeta` reads the fields the Studio actually stores — `robots.noIndex` / `noFollow`, `openGraph.imageType === 'url' ? imageUrl : image` — and cascades meta → Open Graph → X. Pass `imageUrlResolver: (img) => urlFor(img).width(1200).height(630).url()` for hotspot-aware crops.

Sitemaps:

```ts
import {indexableFilter} from '@palmbay/sanity-seo/next'
const pages = await client.fetch(`*[_type in $types && ${indexableFilter}]{ "slug": slug.current, _updatedAt }`, {types})
```

JSON-LD:

```tsx
import {JsonLd, localBusinessJsonLd} from '@palmbay/sanity-seo/next'
<JsonLd data={localBusinessJsonLd({type: 'Photographer', name, url, telephone, address, openingHours, aggregateRating})} />
```

## Onboarding tours (Sanity 6)

```ts
import {onboardingTool} from 'sanity-plugin-editor-onboarding'
import {palmBayTours, palmBayFieldGuides} from '@palmbay/sanity-seo/onboarding'

plugins: [onboardingTool({tours: palmBayTours({siteName: 'Cork & Capture'}), fieldGuides: palmBayFieldGuides()})]
```

## Credits

The `seoFields` schema and the search preview are derived from [sanity-plugin-seofields](https://github.com/hardik-143/sanity-plugin-seofields) by Desai Hardik (MIT). The health tool, publish validator, AI drafts, alt text and Next.js helpers are original work. Nothing from the proprietary `seofields-pro` package is used.

## Develop

```sh
pnpm install
pnpm test        # vitest
pnpm run build   # @sanity/pkg-utils
```

MIT © Palm Bay Digital
