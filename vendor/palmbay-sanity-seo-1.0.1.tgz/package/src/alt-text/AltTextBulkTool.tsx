import {Badge, Box, Button, Card, Container, Flex, Heading, Spinner, Text, TextInput} from '@sanity/ui'
import type React from 'react'
import {useCallback, useEffect, useMemo, useRef, useState} from 'react'
import {useClient, useSchema, type SanityClient} from 'sanity'
import {IntentLink} from 'sanity/router'

import {requestSeoAi} from '../seo-fields/inputs/AiDraftButton'
import {DEFAULT_API_VERSION} from '../seo-fields/options'
import {SEO_LIMITS} from '../shared/types'
import {patchPublishedAndDraft} from '../studio/patchPublishedAndDraft'
import type {AltTextOptions} from './index'

interface ImageHit {
  docId: string
  docType: string
  docTitle: string
  /** JSON path of the image object within the document, e.g. `hero.image` or `gallery[_key=="abc"]` */
  path: string
  assetRef: string
  url: string
  alt: string | null
  /** Marked as carrying no information — renders alt="" and needs no text. */
  decorative: boolean
}

type Status = 'idle' | 'running' | 'done'

/**
 * Walk a published document and yield every image object alongside the Sanity
 * patch path to reach it. Portable Text image blocks are included.
 *
 * An image is identified by an `asset._ref` pointing at an image, NOT by
 * `_type === 'image'`: the recommended Sanity pattern is a *named* image type
 * (`figure`, `mainImage`, …), which stores that name as `_type` and would
 * otherwise be invisible here. Files are excluded by the `image-` prefix.
 */
export function collectImages(
  doc: Record<string, unknown>,
): Array<{path: string; assetRef: string; alt: string | null; decorative: boolean}> {
  const out: Array<{path: string; assetRef: string; alt: string | null; decorative: boolean}> = []
  const walk = (v: unknown, path: string) => {
    if (!v || typeof v !== 'object') return
    if (Array.isArray(v)) {
      v.forEach((item, i) => {
        const key = item && typeof item === 'object' ? (item as {_key?: string})._key : undefined
        walk(item, key ? `${path}[_key=="${key}"]` : `${path}[${i}]`)
      })
      return
    }
    const obj = v as Record<string, unknown>
    const asset = obj.asset as {_ref?: string} | undefined
    if (asset?._ref?.startsWith('image-')) {
      out.push({
        path,
        assetRef: asset._ref,
        alt: typeof obj.alt === 'string' ? obj.alt : null,
        decorative: obj.isDecorative === true,
      })
      return
    }
    for (const [k, val] of Object.entries(obj)) {
      if (k.startsWith('_')) continue
      walk(val, path ? `${path}.${k}` : k)
    }
  }
  walk(doc, '')
  return out
}

export function AltTextBulkTool({options}: {options: AltTextOptions}) {
  const client = useClient({apiVersion: options.apiVersion ?? DEFAULT_API_VERSION})
  const schema = useSchema()
  const endpoint = options.endpoint ?? '/api/seo-ai'
  const types = useMemo(
    () =>
      options.documentTypes?.length
        ? options.documentTypes
        : schema.getTypeNames().filter((n) => {
            const t = schema.get(n) as {type?: {name?: string}} | undefined
            return t?.type?.name === 'document' && !n.startsWith('sanity.')
          }),
    [schema, options.documentTypes],
  )

  const [hits, setHits] = useState<ImageHit[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [status, setStatus] = useState<Status>('idle')
  const [progress, setProgress] = useState({done: 0, failed: 0})
  const [lastFailure, setLastFailure] = useState<string | null>(null)
  const [missingOnly, setMissingOnly] = useState(false)
  const cancelled = useRef(false)

  const load = useCallback(async () => {
    setHits(null)
    setError(null)
    setStatus('idle')
    try {
      const docs = await client.fetch<Array<Record<string, unknown>>>(
        `*[_type in $types && !(_id in path("drafts.**"))]`,
        {types},
      )
      const raw = docs.flatMap((doc) =>
        collectImages(doc).map((img) => ({
          docId: String(doc._id),
          docType: String(doc._type),
          docTitle: String(doc.title ?? doc.name ?? doc._id),
          ...img,
        })),
      )
      const refs = [...new Set(raw.map((r) => r.assetRef))]
      const assets = await client.fetch<Array<{_id: string; url: string}>>(
        `*[_id in $refs]{_id, url}`,
        {refs},
      )
      const urlById = new Map(assets.map((a) => [a._id, a.url]))
      setHits(
        raw
          .map((r) => ({...r, url: urlById.get(r.assetRef) ?? ''}))
          .filter((r) => r.url),
      )
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }, [client, types])

  useEffect(() => {
    load()
  }, [load])

  // A decorative image is finished work, not a gap — it renders alt="" on
  // purpose, so it never counts as missing and never gets generated.
  const missing = useMemo(
    () => (hits ?? []).filter((h) => !h.decorative && !h.alt?.trim()),
    [hits],
  )
  const list = missingOnly ? missing : (hits ?? [])

  const run = useCallback(async () => {
    if (!missing.length) return
    cancelled.current = false
    setStatus('running')
    setProgress({done: 0, failed: 0})
    setLastFailure(null)
    const draftIds = new Set(
      await client.fetch<string[]>(`*[_id in $ids]._id`, {
        ids: [...new Set(missing.map((h) => `drafts.${h.docId}`))],
      }),
    )
    const tx = client.transaction()
    let done = 0
    let failed = 0
    const batchSize = 4
    for (let i = 0; i < missing.length; i += batchSize) {
      if (cancelled.current) break
      const batch = missing.slice(i, i + batchSize)
      const results = await Promise.all(
        batch.map((h) =>
          requestSeoAi(endpoint, {task: 'alt', imageUrl: h.url, context: h.docTitle})
            .then((alt) => ({h, alt}))
            .catch((e: unknown) => ({h, alt: null as string | null, err: e instanceof Error ? e.message : String(e)})),
        ),
      )
      for (const {h, alt, ...rest} of results) {
        if (!alt) {
          failed++
          if ('err' in rest) setLastFailure(rest.err)
          continue
        }
        tx.patch(h.docId, (p) => p.set({[`${h.path}.alt`]: alt}))
        if (draftIds.has(`drafts.${h.docId}`)) {
          tx.patch(`drafts.${h.docId}`, (p) => p.set({[`${h.path}.alt`]: alt}))
        }
        h.alt = alt
        done++
      }
      setProgress({done, failed})
    }
    if (done > 0) await tx.commit({autoGenerateArrayKeys: true})
    setStatus('done')
    setHits((prev) => (prev ? [...prev] : prev))
  }, [missing, client, endpoint])

  return (
    <Box padding={4}>
      <Container width={3}>
        <Flex direction="column" gap={4}>
          <Flex align="center" justify="space-between" gap={3} wrap="wrap">
            <Flex direction="column" gap={2}>
              <Heading as="h1" size={2}>
                Alt Text
              </Heading>
              <Text size={1} muted>
                Every image in a published document and its alt text. Edit inline, generate the
                missing ones in one go, or mark an image decorative when it carries no
                information — that renders <code>alt=""</code> so screen readers skip it. Open
                drafts are updated too, so a later publish won't undo the change.
              </Text>
            </Flex>
            <Flex align="center" gap={2}>
              {hits && (
                <Badge tone={missing.length ? 'caution' : 'positive'} fontSize={1} padding={2}>
                  {missing.length} missing of {hits.length}
                </Badge>
              )}
              <Button
                text={missingOnly ? 'Show all' : 'Show missing only'}
                mode="ghost"
                onClick={() => setMissingOnly((s) => !s)}
              />
              <Button text="Refresh" mode="ghost" onClick={load} disabled={status === 'running'} />
              {status === 'running' ? (
                <Button
                  text={`Stop (${progress.done} done)`}
                  tone="critical"
                  onClick={() => {
                    cancelled.current = true
                  }}
                />
              ) : (
                <Button
                  text={`Generate ${missing.length} with AI`}
                  tone="primary"
                  disabled={!missing.length}
                  onClick={run}
                />
              )}
            </Flex>
          </Flex>

          {status === 'done' && (
            <Card tone={progress.failed ? 'caution' : 'positive'} padding={3} radius={2}>
              <Text size={1}>
                Wrote {progress.done} alt text{progress.done === 1 ? '' : 's'}
                {progress.failed ? `; ${progress.failed} failed.` : '.'}
                {lastFailure ? ` ${lastFailure}` : ''}
              </Text>
            </Card>
          )}
          {error && (
            <Card tone="critical" padding={3} radius={2}>
              <Text size={1}>{error}</Text>
            </Card>
          )}
          {!hits && !error && (
            <Flex justify="center" padding={5}>
              <Spinner />
            </Flex>
          )}

          <Flex direction="column" gap={2}>
            {list.map((h) => (
              <AltRow
                key={`${h.docId}:${h.path}`}
                hit={h}
                client={client}
                endpoint={endpoint}
                disabled={status === 'running'}
                onSaved={(patch) => {
                  Object.assign(h, patch)
                  setHits((prev) => (prev ? [...prev] : prev))
                }}
              />
            ))}
          </Flex>
        </Flex>
      </Container>
    </Box>
  )
}

function AltRow({
  hit,
  client,
  endpoint,
  disabled,
  onSaved,
}: {
  hit: ImageHit
  client: SanityClient
  endpoint: string
  disabled: boolean
  onSaved: (patch: Partial<ImageHit>) => void
}) {
  const [value, setValue] = useState(hit.alt ?? '')
  const [busy, setBusy] = useState<'save' | 'ai' | 'decorative' | null>(null)
  const [error, setError] = useState<string | null>(null)
  const dirty = value.trim() !== (hit.alt ?? '').trim()

  // Bulk generation updates hit.alt behind our back; follow it unless the editor is mid-edit.
  useEffect(() => {
    if (!dirty) setValue(hit.alt ?? '')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hit.alt])

  const save = useCallback(async () => {
    const alt = value.trim()
    if (!alt || !dirty) return
    setBusy('save')
    setError(null)
    try {
      await patchPublishedAndDraft(client, hit.docId, {set: {[`${hit.path}.alt`]: alt}})
      onSaved({alt})
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(null)
    }
  }, [value, dirty, client, hit, onSaved])

  // Marking decorative clears any alt text, so the two can never disagree;
  // unmarking leaves the field empty for a real description.
  const toggleDecorative = useCallback(async () => {
    const next = !hit.decorative
    setBusy('decorative')
    setError(null)
    try {
      await patchPublishedAndDraft(client, hit.docId, {
        set: {[`${hit.path}.isDecorative`]: next},
        ...(next ? {unset: [`${hit.path}.alt`]} : {}),
      })
      if (next) setValue('')
      onSaved(next ? {decorative: true, alt: null} : {decorative: false})
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(null)
    }
  }, [hit, client, onSaved])

  const generate = useCallback(async () => {
    setBusy('ai')
    setError(null)
    try {
      setValue(await requestSeoAi(endpoint, {task: 'alt', imageUrl: hit.url, context: hit.docTitle}))
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(null)
    }
  }, [endpoint, hit.url, hit.docTitle])

  return (
    <Card padding={2} radius={2} border>
      <Flex align="center" gap={3}>
        <img
          src={`${hit.url}?w=96&h=64&fit=crop&auto=format`}
          alt=""
          width={96}
          height={64}
          style={{objectFit: 'cover', borderRadius: 4, flex: 'none'}}
        />
        <Flex direction="column" gap={2} flex={1}>
          <Flex align="center" gap={2} wrap="wrap">
            <Text size={1} weight="medium">
              <IntentLink
                intent="edit"
                params={{id: hit.docId, type: hit.docType}}
                style={{color: 'inherit', textDecoration: 'none'}}
              >
                {hit.docTitle}
              </IntentLink>{' '}
              <span style={{opacity: 0.6}}>· {hit.path}</span>
            </Text>
            {hit.decorative ? (
              <Badge tone="primary" fontSize={0}>
                decorative
              </Badge>
            ) : (
              !hit.alt?.trim() && (
                <Badge tone="caution" fontSize={0}>
                  no alt text
                </Badge>
              )
            )}
            {!hit.decorative && (
              <Text size={0} muted>
                {value.trim().length}/{SEO_LIMITS.alt.max}
              </Text>
            )}
          </Flex>
          <Flex align="center" gap={2}>
            <Box flex={1}>
              <TextInput
                fontSize={1}
                padding={2}
                value={hit.decorative ? '' : value}
                placeholder={
                  hit.decorative
                    ? 'Decorative — announced as decoration, no alt text needed'
                    : 'Describe what a visitor would see…'
                }
                disabled={disabled || hit.decorative || busy !== null}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setValue(e.currentTarget.value)}
                onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                  if (e.key === 'Enter') {
                    e.preventDefault()
                    save()
                  }
                }}
              />
            </Box>
            {!hit.decorative && (
              <>
                <Button
                  text={busy === 'ai' ? 'Generating…' : 'AI'}
                  mode="ghost"
                  fontSize={1}
                  padding={2}
                  disabled={disabled || busy !== null}
                  onClick={generate}
                />
                <Button
                  text={busy === 'save' ? 'Saving…' : 'Save'}
                  tone="primary"
                  fontSize={1}
                  padding={2}
                  disabled={disabled || busy !== null || !dirty || !value.trim()}
                  onClick={save}
                />
              </>
            )}
            <Button
              text={hit.decorative ? 'Needs alt text' : 'Decorative'}
              mode="bleed"
              fontSize={1}
              padding={2}
              title={
                hit.decorative
                  ? 'Treat this as a meaningful image that needs a description'
                  : 'This image adds no information — render alt="" so screen readers skip it'
              }
              disabled={disabled || busy !== null}
              onClick={toggleDecorative}
            />
          </Flex>
          {error && (
            <Text size={1} style={{color: 'var(--card-critical-fg-color, #c33)'}}>
              {error}
            </Text>
          )}
        </Flex>
      </Flex>
    </Card>
  )
}
