/**
 * A small schema.org property check for the JSON-LD these builders emit.
 *
 * Rich-results tests ignore properties they don't use, so an invalid one (e.g.
 * `inLanguage` on a LocalBusiness) sails through Google's tester and only shows
 * up later as an Ahrefs / validator.schema.org "schema.org validation error".
 * This catches it at render time instead.
 *
 * It is an allowlist per type, covering the types this package produces plus
 * the common ones a site adds by hand. Types it doesn't know are skipped,
 * except a node whose `@id` ends `#business` (the house convention), which is
 * checked as a LocalBusiness whatever subtype it declares.
 */

type Node = Record<string, unknown>

export interface JsonLdIssue {
  /** e.g. `@graph[0](LocalBusiness).inLanguage` */
  path: string
  type: string
  property: string
  message: string
}

const set = (...groups: Array<readonly string[]>) => new Set(groups.flat())

const THING = [
  '@context', '@type', '@id', 'name', 'description', 'url', 'image', 'sameAs',
  'alternateName', 'identifier', 'mainEntityOfPage', 'potentialAction',
  'disambiguatingDescription', 'additionalType', 'subjectOf',
] as const

const ORGANIZATION = [
  'legalName', 'logo', 'email', 'telephone', 'faxNumber', 'vatID', 'taxID', 'address',
  'contactPoint', 'subOrganization', 'parentOrganization', 'founder', 'foundingDate',
  'foundingLocation', 'areaServed', 'hasOfferCatalog', 'knowsAbout', 'knowsLanguage',
  'aggregateRating', 'review', 'member', 'memberOf', 'numberOfEmployees', 'slogan',
  'award', 'brand', 'department', 'location', 'hasCredential', 'employee', 'owns',
  'iso6523Code', 'leiCode', 'duns', 'naics', 'globalLocationNumber', 'hasMerchantReturnPolicy',
  'interactionStatistic', 'keywords', 'makesOffer', 'seeks', 'sponsor', 'funder',
] as const

const PLACE = [
  'address', 'geo', 'hasMap', 'openingHoursSpecification', 'specialOpeningHoursSpecification',
  'telephone', 'faxNumber', 'aggregateRating', 'review', 'photo', 'latitude', 'longitude',
  'containedInPlace', 'containsPlace', 'amenityFeature', 'publicAccess', 'isAccessibleForFree',
  'maximumAttendeeCapacity', 'smokingAllowed', 'logo', 'slogan', 'keywords', 'branchCode',
  'globalLocationNumber', 'hasDriveThroughService', 'tourBookingPage',
] as const

const LOCAL_BUSINESS = [
  ...ORGANIZATION, ...PLACE,
  'priceRange', 'openingHours', 'currenciesAccepted', 'paymentAccepted', 'branchOf',
] as const

const FOOD_ESTABLISHMENT = [
  'servesCuisine', 'acceptsReservations', 'hasMenu', 'menu', 'starRating',
] as const

const FOOD_TYPES = new Set([
  'FoodEstablishment', 'Restaurant', 'CafeOrCoffeeShop', 'Bakery', 'BarOrPub',
  'FastFoodRestaurant', 'IceCreamShop', 'Winery', 'Brewery', 'Distillery',
])

const CREATIVE_WORK = [
  'inLanguage', 'publisher', 'author', 'creator', 'datePublished', 'dateModified',
  'dateCreated', 'keywords', 'headline', 'about', 'isPartOf', 'hasPart', 'mainEntity',
  'copyrightHolder', 'copyrightYear', 'thumbnailUrl', 'text', 'license', 'mentions',
  'audience', 'genre', 'abstract', 'version', 'contributor', 'editor', 'funder',
  'isAccessibleForFree', 'sourceOrganization', 'spatialCoverage', 'encodingFormat',
  'aggregateRating', 'review', 'video', 'citation', 'position', 'accessMode',
] as const

const WEB_PAGE = [
  ...CREATIVE_WORK,
  'breadcrumb', 'primaryImageOfPage', 'lastReviewed', 'reviewedBy', 'significantLink',
  'relatedLink', 'speakable', 'specialty', 'mainContentOfPage',
] as const

const ARTICLE = [...CREATIVE_WORK, 'articleBody', 'articleSection', 'wordCount', 'speakable'] as const

const PERSON = [
  'givenName', 'familyName', 'additionalName', 'jobTitle', 'worksFor', 'knowsAbout',
  'knowsLanguage', 'memberOf', 'email', 'telephone', 'address', 'affiliation', 'alumniOf',
  'award', 'birthDate', 'gender', 'honorificPrefix', 'honorificSuffix', 'nationality',
  'hasOccupation', 'hasCredential', 'workLocation', 'brand',
] as const

const SERVICE = [
  'serviceType', 'provider', 'areaServed', 'offers', 'hasOfferCatalog', 'audience', 'brand',
  'category', 'logo', 'award', 'availableChannel', 'termsOfService', 'aggregateRating',
  'review', 'serviceOutput', 'providerMobility', 'isRelatedTo', 'isSimilarTo', 'slogan',
  'broker', 'hoursAvailable', 'serviceAudience', 'produces',
] as const

const LIST = ['itemListElement', 'numberOfItems', 'itemListOrder'] as const

const CONTACT_POINT = [
  'contactType', 'telephone', 'email', 'faxNumber', 'areaServed', 'availableLanguage',
  'hoursAvailable', 'contactOption', 'productSupported',
] as const

const RATING = ['ratingValue', 'bestRating', 'worstRating', 'author', 'ratingExplanation'] as const

const page = set(THING, WEB_PAGE)

/** Allowed properties by exact `@type`. */
const ALLOWED: Record<string, Set<string>> = {
  Organization: set(THING, ORGANIZATION),
  LocalBusiness: set(THING, LOCAL_BUSINESS),
  WebSite: set(THING, CREATIVE_WORK, ['issn']),
  WebPage: page,
  AboutPage: page,
  ContactPage: page,
  CollectionPage: page,
  ImageGallery: page,
  ItemPage: page,
  ProfilePage: page,
  SearchResultsPage: page,
  CheckoutPage: page,
  FAQPage: page,
  Article: set(THING, ARTICLE),
  BlogPosting: set(THING, ARTICLE, ['sharedContent']),
  NewsArticle: set(THING, ARTICLE, ['dateline', 'printSection', 'printPage']),
  Service: set(THING, SERVICE),
  Person: set(THING, PERSON),
  BreadcrumbList: set(THING, LIST),
  ItemList: set(THING, LIST),
  OfferCatalog: set(THING, LIST),
  ListItem: set(THING, ['position', 'item', 'nextItem', 'previousItem']),
  Offer: set(THING, [
    'price', 'priceCurrency', 'itemOffered', 'availability', 'validFrom', 'validThrough',
    'priceValidUntil', 'seller', 'offeredBy', 'priceSpecification', 'category', 'eligibleRegion',
    'areaServed', 'businessFunction', 'availabilityStarts', 'availabilityEnds', 'url',
  ]),
  PostalAddress: set(THING, CONTACT_POINT, [
    'streetAddress', 'addressLocality', 'addressRegion', 'postalCode', 'addressCountry',
    'postOfficeBoxNumber',
  ]),
  ContactPoint: set(THING, CONTACT_POINT),
  GeoCoordinates: set(THING, ['latitude', 'longitude', 'elevation', 'address', 'addressCountry', 'postalCode']),
  OpeningHoursSpecification: set(THING, ['dayOfWeek', 'opens', 'closes', 'validFrom', 'validThrough']),
  ImageObject: set(THING, CREATIVE_WORK, [
    'contentUrl', 'width', 'height', 'caption', 'embedUrl', 'representativeOfPage', 'exifData',
  ]),
  AggregateRating: set(THING, RATING, ['reviewCount', 'ratingCount', 'itemReviewed']),
  Rating: set(THING, RATING),
  Review: set(THING, CREATIVE_WORK, ['reviewBody', 'reviewRating', 'itemReviewed']),
  Question: set(THING, CREATIVE_WORK, ['acceptedAnswer', 'suggestedAnswer', 'answerCount']),
  Answer: set(THING, CREATIVE_WORK, ['upvoteCount']),
  Menu: set(THING, CREATIVE_WORK, ['hasMenuSection', 'hasMenuItem']),
  MenuSection: set(THING, CREATIVE_WORK, ['hasMenuSection', 'hasMenuItem']),
  MenuItem: set(THING, ['offers', 'suitableForDiet', 'menuAddOn', 'nutrition']),
  SearchAction: set(THING, ['target', 'query-input', 'query', 'object', 'result']),
  EntryPoint: set(THING, ['urlTemplate', 'actionPlatform', 'contentType', 'encodingType', 'httpMethod']),
  City: set(THING, PLACE),
  AdministrativeArea: set(THING, PLACE),
  Country: set(THING, PLACE),
  State: set(THING, PLACE),
  Place: set(THING, PLACE),
}

const types = (node: Node): string[] => {
  const t = node['@type']
  return Array.isArray(t) ? t.map(String) : typeof t === 'string' ? [t] : []
}

/** The properties a node may carry, or null when we don't know its type. */
function allowedFor(node: Node): Set<string> | null {
  const ts = types(node)
  const known = ts.map((t) => ALLOWED[t]).filter((k): k is Set<string> => !!k)
  const isBusiness =
    ts.some((t) => t === 'LocalBusiness' || FOOD_TYPES.has(t)) ||
    (typeof node['@id'] === 'string' && /#business$/.test(node['@id'] as string))
  if (isBusiness) {
    const s = new Set(ALLOWED.LocalBusiness)
    if (ts.some((t) => FOOD_TYPES.has(t))) FOOD_ESTABLISHMENT.forEach((p) => s.add(p))
    return s
  }
  if (known.length === 0) return null
  // Multi-typed nodes may use the union of their types' properties.
  return new Set(known.flatMap((k) => [...k]))
}

const isNode = (v: unknown): v is Node => typeof v === 'object' && v !== null && !Array.isArray(v)

/** Every property schema.org doesn't define for its node's type. */
export function validateJsonLd(doc: unknown): JsonLdIssue[] {
  const issues: JsonLdIssue[] = []
  const walk = (v: unknown, path: string) => {
    if (Array.isArray(v)) return v.forEach((x, i) => walk(x, `${path}[${i}]`))
    if (!isNode(v)) return
    const allowed = allowedFor(v)
    const label = types(v).join(',') || '?'
    for (const [k, child] of Object.entries(v)) {
      if (k === '@graph') {
        walk(child, '@graph')
        continue
      }
      if (allowed && !allowed.has(k)) {
        issues.push({
          path: `${path}(${label}).${k}`,
          type: label,
          property: k,
          message: `"${k}" is not a schema.org property of ${label}`,
        })
      }
      walk(child, `${path}(${label}).${k}`)
    }
  }
  walk(doc, '')
  return issues
}

/** Throws with every issue listed. For tests and build scripts. */
export function assertValidJsonLd(doc: unknown): void {
  const issues = validateJsonLd(doc)
  if (issues.length) {
    throw new Error(
      `Invalid JSON-LD (palmbay-structured-data):\n${issues.map((i) => `  - ${i.path}: ${i.message}`).join('\n')}`,
    )
  }
}

/**
 * Called by `graph()`. Development: throw, so the page errors on screen and the
 * bad property never ships. Production (incl. `next build`): log to stderr,
 * never take the site down over markup.
 */
export function reportJsonLdIssues(doc: unknown): void {
  const env = typeof process !== 'undefined' ? process.env?.NODE_ENV : undefined
  if (env === 'production') {
    const issues = validateJsonLd(doc)
    if (issues.length) {
      console.error(
        `[@palmbay/sanity-seo] Invalid JSON-LD:\n${issues.map((i) => `  - ${i.path}: ${i.message}`).join('\n')}`,
      )
    }
    return
  }
  assertValidJsonLd(doc)
}
