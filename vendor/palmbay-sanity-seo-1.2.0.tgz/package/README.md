# @palmbay/sanity-seo

Palm Bay Digital's Sanity Studio SEO toolkit, in one package:

| Module | What it gives you |
| --- | --- |
| `seoFields()` | The `seoFields` object type (meta title/description with counters and duplicate check, share image, focus keyword, robots, canonical, hreflang, Open Graph, X), a live Google search preview, and an **SEO Health** tab that scores every page 0–100. |
| `openSeo()` | A **Rank Tracking** tab embedding a read-only [OpenSEO](https://openseo.so) share link. |
| **SEO Health** | Expand any page to edit its meta title, description, focus keyword, canonical and Open Graph copy in place, each with an AI button — and to upload or link the share, Open Graph and X images without leaving the tool. A missing share image is 20 of the 100 points, the largest single component. |
| `altText()` + `altTextField()` | A "Generate alt text" button on any image, and an **Alt Text** tab that finds every image with no description and fills them in one transaction. |
| `@palmbay/sanity-seo/next` | `buildSeoMeta()` for `generateMetadata`, the matching `seoProjection` GROQ fragment, `isIndexable()` for sitemaps, and JSON-LD builders (`localBusinessJsonLd`, `articleJsonLd`, `faqPageJsonLd`, …) with a `<JsonLd/>` component. |
| `@palmbay/sanity-seo/server` | `createSeoAiHandler()` — the Next.js route the AI buttons call. Claude runs server-side; the key never reaches the browser. Give it an OpenSEO share link and the drafts are steered by what the site already ranks for. |
| `@palmbay/sanity-seo/onboarding` | `palmBayTours()` / `palmBayFieldGuides()` for [sanity-plugin-editor-onboarding](https://www.sanity.io/plugins/sanity-plugin-editor-onboarding) (Sanity 6 only). |

The `seoFields` schema is field-for-field compatible with `sanity-plugin-seofields` v1.x, so swapping the plugin needs no content migration. No licence keys anywhere.

## Install

```sh
npm install @palmbay/sanity-seo @anthropic-ai/sdk
# Only if you want the onboarding tours (Sanity 6 studios):
npm install sanity-plugin-editor-onboarding
```

`sanity-plugin-editor-onboarding` is deliberately **not** a peer dependency: it is Sanity 6 only, and npm resolves optional peers eagerly, so declaring it broke installs on every Sanity 4 and 5 studio. Import `@palmbay/sanity-seo/onboarding` only once you've installed it yourself.

Peers: `sanity ^4 || ^5 || ^6`, `react ^18 || ^19`. `@sanity/ui` is declared as `^3 || ^4` so it dedupes to whatever your Studio already ships.

## Studio

```ts
// sanity.config.ts
import {defineConfig} from 'sanity'
import {seoFields, openSeo, altText} from '@palmbay/sanity-seo'

export default defineConfig({
  // ...
  plugins: [
    seoFields({titleSuffix: 'Cork & Capture'}), // the " | Brand" your layout appends
    altText(),
    openSeo({embedUrl: process.env.NEXT_PUBLIC_OPENSEO_EMBED_URL}),
  ],
})
```

```ts
// every page-level document type
import {requiredSeo, altTextField} from '@palmbay/sanity-seo'

defineField({name: 'seo', type: 'seoFields', validation: requiredSeo})
defineField({name: 'image', type: 'image', fields: [altTextField()]})
```

`requiredSeo` blocks publishing until title, description and a share image are set.

Options for `seoFields()`: `titleSuffix` / `titleSuffixQuery`, `baseUrl` (for the preview URL), `ai: {endpoint}` or `ai: false`, `healthTool: false`, `healthDocumentTypes: [...]`.

### Standalone (Vite) studios

There is no Next.js route, so pass `ai: false` (or an absolute `ai.endpoint` on a host that runs the handler) and read the OpenSEO URL from `import.meta.env.VITE_…`.

## The AI route (Next.js App Router)

```ts
// app/api/seo-ai/route.ts
import {createSeoAiHandler} from '@palmbay/sanity-seo/server'
export const POST = createSeoAiHandler()
```

Set `ANTHROPIC_API_KEY` on the server (a **Sensitive** Vercel env var). The handler is same-origin only, rate-limited per IP, and will only describe images on this project's Sanity CDN (`NEXT_PUBLIC_SANITY_PROJECT_ID`). Options: `altModel` (default `claude-haiku-4-5`), `textModel` (default `claude-sonnet-5`), `language`, `allowedImageHosts`, `allowedOrigins`, `rateLimitPerMinute`, `openSeoEmbedUrl`.

### Keyword-aware drafts

Point the handler at the same OpenSEO share link the `openSeo()` tab embeds and the title, description and focus-keyword drafts stop guessing:

```ts
export const POST = createSeoAiHandler({
  openSeoEmbedUrl: process.env.OPENSEO_EMBED_URL, // or NEXT_PUBLIC_OPENSEO_EMBED_URL
})
```

The route reads `<share link>?format=json` server-side (cached 10 minutes) and hands Claude, for the page being edited: the tracked keywords whose ranking URL is this page, the Search Console queries attributed to this page over the last 28 days, and — as a fallback — the site's own tracked ranks, top queries and saved keyword ideas. Terms sitting in positions 4–20 are ranked first, because moving one of those onto page one is worth more than starting from nothing.

**Focus keyword** gets a **Suggest** button instead of a draft: three to five candidates, each with its measured position and impressions and a one-line reason, and one click fills the field. Open Graph copy deliberately skips the keyword context — it is read in a feed, not a search result.

This needs the page's slug to attribute queries; without one the suggestions fall back to site-wide. Requires OpenSEO Search Console to be connected — no share link, or no GSC, and the buttons quietly behave as before.

## The site

```ts
// app/about/page.tsx
import {buildSeoMeta, seoProjection} from '@palmbay/sanity-seo/next'

export async function generateMetadata() {
  const page = await client.fetch(`*[_type == "aboutPage"][0]{ title, ${seoProjection} }`)
  return buildSeoMeta({
    seo: page?.seo,
    baseUrl: process.env.NEXT_PUBLIC_SITE_URL!,
    path: '/about',
    defaults: {title: 'About', description: '…', image: `${SITE_URL}/og.png`, siteName: 'Brand'},
  })
}
```

`buildSeoMeta` reads the fields the Studio actually stores — `robots.noIndex` / `noFollow`, `openGraph.imageType === 'url' ? imageUrl : image` — and cascades meta → Open Graph → X. Pass `imageUrlResolver: (img) => urlFor(img).width(1200).height(630).url()` for hotspot-aware crops.

Sitemaps:

```ts
import {indexableFilter} from '@palmbay/sanity-seo/next'
const pages = await client.fetch(`*[_type in $types && ${indexableFilter}]{ "slug": slug.current, _updatedAt }`, {types})
```

JSON-LD — one `@graph` per page, server-rendered, every node with a stable `@id`
(`ids.*`) so nodes on different pages reference the same business. The
`palmbay-structured-data` playbook says which types go on which page.

```tsx
import {JsonLd, graph, ids, ref, localBusinessJsonLd, webSiteJsonLd, webPageJsonLd, breadcrumbJsonLd} from '@palmbay/sanity-seo/next'

const business = localBusinessJsonLd({
  type: 'Plumber',                 // most specific subtype; an array for multi-trade
  name, url: SITE_URL, telephone, email, image, priceRange: '££',
  logo: {url: absoluteUrl('/icon.png'), width: 512, height: 512}, // a real file that returns 200
  contactPoint: {telephone, email, areaServed: 'GB', availableLanguage: ['English']},
  address: {…, addressCountry: 'GB'}, geo, openingHours, areaServed, sameAs,
  // no inLanguage here: it isn't a LocalBusiness property (put it on WebSite/WebPage)
})
<JsonLd data={graph([
  business,
  webSiteJsonLd({name, url: SITE_URL, publisher: ref(ids.business(SITE_URL)), inLanguage: 'en-GB'}),
  webPageJsonLd({url: pageUrl, name: title, isPartOf: ref(ids.website(SITE_URL)), about: ref(ids.business(SITE_URL)), breadcrumb: ref(ids.breadcrumb(pageUrl))}),
  breadcrumbJsonLd([{name: 'Home', url: SITE_URL}, {name: title}], {id: ids.breadcrumb(pageUrl)}),
])} />
```

Service pages add `serviceJsonLd({provider: ref(ids.business(SITE_URL)), …})` with the
business node on the same page; posts add `articleJsonLd({publisher: ref(…), …})`;
multi-location sites add `organizationJsonLd({subOrganization: [ref(…)]})` and one
business node per location with `parentOrganization`. Also: `itemListJsonLd`,
`menuJsonLd`, `personJsonLd`, `faqPageJsonLd` (valid, but Google retired FAQ rich
results in May 2026). Don't use `ProfessionalService` (deprecated by schema.org),
`Photographer` (not a type) or self-authored `aggregateRating` (Google's self-serving
rule ignores it).

**Validation (1.2.0+).** `graph()` checks every node against a schema.org
property allowlist for its `@type`. A property schema.org doesn't define for that
type (the classic one is `inLanguage` on the business node) **throws in
development** and logs to stderr in production builds. Use
`validateJsonLd(doc)` / `assertValidJsonLd(doc)` in tests or scripts. Google's
Rich Results Test ignores unknown properties, so a page can pass it while
validator.schema.org and Ahrefs report errors. Always check validator.schema.org too.

### Upgrading to 1.2.0
- `inLanguage` on `localBusinessJsonLd` / `serviceJsonLd` is now ignored (and
  deprecated in the types). Upgrading clears the Ahrefs "Structured data has
  schema.org validation error" on every page. Delete the argument when convenient.
- `logo` accepts `{url, width, height}` and is emitted as an `ImageObject`. Make sure
  the file exists: a 404 logo is what Ahrefs reports as "Organization schema
  missing or incomplete".
- New `contactPoint` and `knowsAbout` inputs on the business node.

## Onboarding tours (Sanity 6)

```ts
import {onboardingTool} from 'sanity-plugin-editor-onboarding'
import {palmBayTours, palmBayFieldGuides} from '@palmbay/sanity-seo/onboarding'

plugins: [onboardingTool({tours: palmBayTours({siteName: 'Cork & Capture'}), fieldGuides: palmBayFieldGuides()})]
```

The tours tell editors the brand is appended to every meta title, which is true when `seoFields({titleSuffix})` is set. On a site that stores the complete title and sets no suffix, pass `brandAppended: false`, or editors will be told to strip the brand out of Google:

```ts
palmBayTours({siteName: 'Palms Pizzeria', brandAppended: false})
```

## Credits

The `seoFields` schema and the search preview are derived from [sanity-plugin-seofields](https://github.com/hardik-143/sanity-plugin-seofields) by Desai Hardik (MIT). The health tool, publish validator, AI drafts, alt text and Next.js helpers are original work. Nothing from the proprietary `seofields-pro` package is used.

## Develop

```sh
pnpm install
pnpm test        # vitest
pnpm run build   # @sanity/pkg-utils
```

MIT © Palm Bay Digital
